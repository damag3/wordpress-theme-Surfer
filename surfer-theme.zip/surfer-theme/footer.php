<?php
/**
 * The template for displaying the footer
 */
?>

</div> <!-- End #swup -->

<?php 
$options = get_option('surfer_options', array());
$f_bg    = $options['footer_bg_color'] ?? '#000000';
$f_text  = $options['footer_text_color'] ?? '#ffffff';
$f_cols  = (int)($options['footer_columns'] ?? '3');
$f_copy  = $options['footer_copy'] ?? 'All rights reserved.';
$f_date  = ($options['footer_show_date'] ?? '') === 'on' ? date('Y') . ' ' : '';

// Map columns to grid classes
$grid_class = 'grid-' . $f_cols;
?>

<footer class="site-footer" style="background-color: <?php echo esc_attr($f_bg); ?>; color: <?php echo esc_attr($f_text); ?>;">
    <div class="container">
        <div class="grid <?php echo esc_attr($grid_class); ?>">
            <?php for ($i = 1; $i <= $f_cols; $i++) : ?>
                <div class="footer-col">
                    <?php if (is_active_sidebar("footer-col-$i")) : ?>
                        <?php dynamic_sidebar("footer-col-$i"); ?>
                    <?php else : ?>
                        <?php if ($i == 1) : ?>
                            <h2 class="logo-text">SURFER</h2>
                            <p class="opacity-50">Exploring the limits of photography and wilderness.</p>
                        <?php elseif ($i == 2) : ?>
                            <h4>Navigation</h4>
                            <?php wp_nav_menu(array('theme_location' => 'footer', 'menu_class' => 'footer-menu')); ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endfor; ?>
        </div>

        <div class="footer-bottom flex flex-between">
            <p class="copyright"><?php echo esc_html($f_date . $f_copy); ?></p>
            
            <div class="social-links flex gap-md">
                <?php 
                // Prefer Surfer Panel social, fallback to bio options
                $bio_opt = get_option('surfer_bio_options', array());
                $social_panel = $options['social'] ?? array();

                $social_map = array(
                    'instagram' => array('icon' => 'photo_camera', 'label' => 'Instagram'),
                    'facebook'  => array('icon' => 'link',         'label' => 'Facebook'),
                    'youtube'   => array('icon' => 'play_circle',  'label' => 'YouTube'),
                    'tiktok'    => array('icon' => 'play_circle',  'label' => 'TikTok'),
                    'twitter'   => array('icon' => 'link',         'label' => 'X'),
                    'linkedin'  => array('icon' => 'link',         'label' => 'LinkedIn'),
                    'vimeo'     => array('icon' => 'play_circle',  'label' => 'Vimeo'),
                    'pinterest' => array('icon' => 'link',         'label' => 'Pinterest'),
                );

                foreach ($social_map as $key => $info) :
                    // Panel first, then bio fallback
                    $url = !empty($social_panel[$key]) ? $social_panel[$key]
                         : ($bio_opt['social_'.$key] ?? '');
                    if (!$url) continue;
                ?>
                    <a href="<?php echo esc_url($url); ?>" target="_blank" class="social-link" title="<?php echo esc_attr($info['label']); ?>">
                        <span class="material-symbols-outlined"><?php echo esc_html($info['icon']); ?></span>
                    </a>
                <?php endforeach; ?>

                <?php
                // Custom networks from panel
                $custom_socials = $options['social_custom'] ?? array();
                if (is_array($custom_socials)) :
                    foreach ($custom_socials as $custom) :
                        $c_url   = $custom['url']   ?? '';
                        $c_label = $custom['label'] ?? 'Link';
                        if (!$c_url) continue;
                ?>
                    <a href="<?php echo esc_url($c_url); ?>" target="_blank" class="social-link" title="<?php echo esc_attr($c_label); ?>">
                        <span class="material-symbols-outlined">link</span>
                    </a>
                <?php endforeach; endif; ?>
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
<?php 
$options = get_option('surfer_options', array());
$is_boxed = ($options['site_layout'] ?? 'wide') === 'boxed';
if ($is_boxed) : ?></div><!-- .site-wrapper-boxed --><?php endif; 
?>
</body>
</html>
