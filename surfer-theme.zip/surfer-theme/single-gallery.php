<?php
/**
 * The template for displaying Single Gallery
 */

get_header(); ?>

<?php while (have_posts()) : the_post(); ?>
    <main class="site-main">
        <header class="gallery-header section-padding">
            <div class="container text-center">
                <span class="text-uppercase text-accent mb-sm display-block">Gallery</span>
                <h1 class="mb-lg"><?php the_title(); ?></h1>
                <?php if (has_excerpt()) : ?>
                    <div class="gallery-excerpt opacity-50 max-w-xl mx-auto">
                        <?php the_excerpt(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </header>

        <section class="gallery-content pb-3xl">
            <div class="container-fluid">
                <?php surfer_maybe_render_spots(get_the_ID(), 'before'); ?>
                <?php surfer_maybe_render_videos(get_the_ID(), 'before'); ?>
                <?php 
                $content = get_the_content();
                if (has_block('gallery')) :
                    the_content();
                else :
                    the_content();
                endif;
                ?>
                <?php surfer_maybe_render_spots(get_the_ID(), 'after'); ?>
                <?php surfer_maybe_render_videos(get_the_ID(), 'after'); ?>
            </div>
        </section>

        <!-- Navigation -->
        <div class="gallery-navigation py-xl border-top">
            <div class="container">
                <div class="flex flex-between">
                    <div class="nav-prev"><?php previous_post_link('%link', '&larr; Previous Gallery'); ?></div>
                    <?php get_template_part('templates/social-links', null, array('label' => 'Follow:')); ?>
                    <div class="nav-next"><?php next_post_link('%link', 'Next Gallery &rarr;'); ?></div>
                </div>
            </div>
        </div>
    </main>
<?php endwhile; ?>

<?php get_footer(); ?>
