<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
    <script>
        (function() {
            const theme = localStorage.getItem('theme') || 'light';
            document.documentElement.setAttribute('data-theme', theme);
        })();
    </script>
</head>

<?php
$options = get_option('surfer_options', array());
$is_boxed = ($options['site_layout'] ?? 'wide') === 'boxed';
$body_classes = $is_boxed ? array('is-boxed') : array();
?>
<body <?php body_class($body_classes); ?>>
<?php wp_body_open(); ?>

<?php if ($is_boxed) : ?><div class="site-wrapper-boxed"><?php endif; ?>

<!-- Page Transition Overlay -->
<div class="page-transition-overlay"></div>

<!-- Fullscreen Navigation -->
<div class="fullscreen-nav">
    <div class="nav-container">
        <nav class="overlay-menu">
            <?php wp_nav_menu( array( 
                'theme_location' => 'primary',
                'container' => false,
                'menu_class' => 'overlay-menu-list' 
            ) ); ?>
        </nav>
    </div>
</div>

<div id="swup" class="transition-fade">
    <header class="site-header is-transparent">
        <div class="container flex flex-between">
            <div class="logo">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo-link">
                    <?php 
                    $options = get_option('surfer_options', array());
                    if ( !empty($options['logo_light']) ) : ?>
                        <img src="<?php echo esc_url($options['logo_light']); ?>" alt="<?php bloginfo('name'); ?>" class="logo-img">
                    <?php else : ?>
                        <span class="logo-text"><?php bloginfo( 'name' ); ?></span>
                    <?php endif; ?>
                </a>
            </div>
            
            <nav class="nav-menu">
                <?php wp_nav_menu( array( 
                    'theme_location' => 'primary',
                    'container' => false,
                    'menu_class' => 'main-menu-list' 
                ) ); ?>
            </nav>

            <div class="header-actions flex items-center gap-md">
                <button class="menu-toggle" aria-label="Toggle Menu">
                    <span class="burger-line"></span>
                    <span class="burger-line"></span>
                    <span class="burger-line"></span>
                </button>
            </div>
        </div>
    </header>

    <?php 
    // Banner logic for sub-pages
    $show_banner = get_post_meta(get_the_ID(), '_surfer_show_banner', true) === 'on';
    if ($show_banner && !is_front_page()) : 
        $banner_img   = get_post_meta(get_the_ID(), '_surfer_banner_image', true);
        $banner_h_raw = get_post_meta(get_the_ID(), '_surfer_banner_height', true) ?: '60vh';
        // Normalise old Tailwind-style values
        $banner_h_map = array('h-[30vh]' => '30vh', 'h-[50vh]' => '50vh', 'h-[70vh]' => '70vh', 'h-[80vh]' => '80vh', 'h-screen' => '100vh', 'h-60vh' => '60vh');
        $banner_h     = $banner_h_map[$banner_h_raw] ?? $banner_h_raw;

        // Banner Layout
        $banner_layout = get_post_meta(get_the_ID(), '_surfer_banner_layout', true) ?: 'wide';
        $breakout_cls  = $banner_layout === 'boxed' ? 'container' : 'breakout-full';
    ?>
        <section class="hero-section <?php echo esc_attr($breakout_cls); ?>" style="height: <?php echo esc_attr($banner_h); ?>; min-height: <?php echo esc_attr($banner_h); ?>;">
            <div class="hero-bg">
                <?php if ($banner_img) : ?>
                    <img src="<?php echo esc_url($banner_img); ?>" alt="<?php the_title(); ?>">
                <?php endif; ?>
            </div>
            <div class="hero-content">
                <h1 class="hero-title"><?php the_title(); ?></h1>
                <?php if (is_single()) : ?>
                    <span class="hero-subtitle"><?php echo get_the_date(); ?></span>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>
