<?php
/**
 * Template Part: Social Links from Surfer Panel
 * Usage: get_template_part('templates/social-links');
 * Optional: pass $args['label'] and $args['style'] (inline|block)
 */

$options      = get_option('surfer_options', array());
$bio_opt      = get_option('surfer_bio_options', array());
$social_panel = $options['social'] ?? array();

$social_map = array(
    'instagram' => array('icon' => 'photo_camera', 'label' => 'Instagram'),
    'facebook'  => array('icon' => 'link',         'label' => 'Facebook'),
    'youtube'   => array('icon' => 'play_circle',  'label' => 'YouTube'),
    'tiktok'    => array('icon' => 'play_circle',  'label' => 'TikTok'),
    'twitter'   => array('icon' => 'link',         'label' => 'X'),
    'linkedin'  => array('icon' => 'link',         'label' => 'LinkedIn'),
    'vimeo'     => array('icon' => 'play_circle',  'label' => 'Vimeo'),
    'pinterest' => array('icon' => 'link',         'label' => 'Pinterest'),
);

// Collect all links: panel first, fallback to bio, then custom
$links = array();
foreach ($social_map as $key => $info) {
    $url = !empty($social_panel[$key]) ? $social_panel[$key]
         : ($bio_opt['social_'.$key] ?? '');
    if ($url) $links[] = array('url' => $url, 'icon' => $info['icon'], 'label' => $info['label']);
}

// Custom networks
$custom_socials = $options['social_custom'] ?? array();
if (is_array($custom_socials)) {
    foreach ($custom_socials as $custom) {
        if (!empty($custom['url'])) {
            $links[] = array(
                'url'   => $custom['url'],
                'icon'  => 'link',
                'label' => $custom['label'] ?? 'Link',
            );
        }
    }
}

if (empty($links)) return; // nothing to render

$heading = $args['label'] ?? '';
?>
<div class="surfer-social-links">
    <?php if ($heading) : ?>
        <span class="social-links-label"><?php echo esc_html($heading); ?></span>
    <?php endif; ?>
    <div class="flex gap-md flex-wrap">
        <?php foreach ($links as $l) : ?>
            <a href="<?php echo esc_url($l['url']); ?>"
               target="_blank"
               rel="noopener noreferrer"
               class="social-link"
               title="<?php echo esc_attr($l['label']); ?>">
                <span class="material-symbols-outlined"><?php echo esc_html($l['icon']); ?></span>
            </a>
        <?php endforeach; ?>
    </div>
</div>
