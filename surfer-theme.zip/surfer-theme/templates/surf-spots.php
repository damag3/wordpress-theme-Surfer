<?php
/**
 * Template Part: Surf Spots Module
 * Usage: get_template_part('templates/surf-spots', null, $args);
 * Args:
 *   count   (int)    — number of spots to show (default: 6)
 *   cols    (int)    — columns 2|3 (default: 3)
 *   title   (string) — section heading
 *   subtitle(string) — eyebrow label
 */

$count    = isset($args['count'])    ? intval($args['count'])         : 6;
$cols     = isset($args['cols'])     ? intval($args['cols'])          : 3;
$title    = isset($args['title'])    ? sanitize_text_field($args['title'])    : 'Surf Spots';
$subtitle = isset($args['subtitle']) ? sanitize_text_field($args['subtitle']) : 'Discover';
$layout   = isset($args['layout'])   ? sanitize_text_field($args['layout'])   : 'container';

$q = new WP_Query(array(
    'post_type'      => 'surf_spot',
    'posts_per_page' => $count,
    'post_status'    => 'publish',
));

if (!$q->have_posts()) { wp_reset_postdata(); return; }

$level_colors = array(
    'Beginner'                 => '#4ade80',
    'Beginner / Intermediate'  => '#a3e635',
    'Intermediate'             => '#facc15',
    'Intermediate / Advanced'  => '#fb923c',
    'Advanced'                 => '#f87171',
    'Expert / Pro'             => '#c084fc',
);
$layout_cls = $layout === 'container-fluid' ? 'breakout-full' : '';
?>
<section class="surfer-spots-module section-padding <?php echo esc_attr($layout_cls); ?>">
    <div class="<?php echo esc_attr($layout); ?>">
        <?php if ($title || $subtitle) : ?>
        <div class="text-center mb-3xl">
            <?php if ($subtitle) : ?><span class="text-uppercase text-accent mb-sm display-block"><?php echo esc_html($subtitle); ?></span><?php endif; ?>
            <?php if ($title)    : ?><h2><?php echo esc_html($title); ?></h2><?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="grid grid-<?php echo esc_attr($cols); ?> spots-grid">
            <?php while ($q->have_posts()) : $q->the_post();
                $wave   = get_post_meta(get_the_ID(), '_spot_wave_type', true);
                $bottom = get_post_meta(get_the_ID(), '_spot_bottom', true);
                $swell  = get_post_meta(get_the_ID(), '_spot_swell', true);
                $wind   = get_post_meta(get_the_ID(), '_spot_wind', true);
                $tide   = get_post_meta(get_the_ID(), '_spot_tide', true);
                $level  = get_post_meta(get_the_ID(), '_spot_level', true);
                $season = get_post_meta(get_the_ID(), '_spot_best_season', true);
                $swell_sz = get_post_meta(get_the_ID(), '_spot_swell_size', true);
                $lvl_color = $level_colors[$level] ?? 'var(--color-accent)';
            ?>
            <article class="spot-card">
                <?php if (has_post_thumbnail()) : ?>
                <a href="<?php the_permalink(); ?>" class="spot-card__image">
                    <?php the_post_thumbnail('large'); ?>
                    <?php if ($level) : ?>
                    <span class="spot-level-badge" style="background-color:<?php echo esc_attr($lvl_color); ?>">
                        <?php echo esc_html($level); ?>
                    </span>
                    <?php endif; ?>
                </a>
                <?php endif; ?>
                <div class="spot-card__body">
                    <h3 class="spot-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="spot-card__specs">
                        <?php $quick = array_filter(array('Wave' => $wave, 'Bottom' => $bottom, 'Tide' => $tide)); ?>
                        <?php foreach ($quick as $lbl => $val) : ?>
                            <span class="spot-spec-tag"><em><?php echo esc_html($lbl); ?>:</em> <?php echo esc_html($val); ?></span>
                        <?php endforeach; ?>
                        <?php if ($swell) : ?>
                            <span class="spot-spec-tag"><em>Swell:</em> <?php echo esc_html($swell); ?></span>
                        <?php endif; ?>
                        <?php if ($wind) : ?>
                            <span class="spot-spec-tag"><em>Wind:</em> <?php echo esc_html($wind); ?></span>
                        <?php endif; ?>
                        <?php if ($season) : ?>
                            <span class="spot-spec-tag"><em>Season:</em> <?php echo esc_html($season); ?></span>
                        <?php endif; ?>
                    </div>
                    <a href="<?php the_permalink(); ?>" class="btn btn-dark" style="margin-top:1rem;font-size:0.65rem;">View Spot &rarr;</a>
                </div>
            </article>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
    </div>
</section>
