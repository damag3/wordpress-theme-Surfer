<?php
/**
 * Template Part: Videos Module
 * Usage: get_template_part('templates/videos', null, $args);
 * Args:
 *   count   (int)    — number of videos to show (default: 3)
 *   cols    (int)    — columns 2|3|4 (default: 3)
 *   title   (string) — section heading
 *   subtitle(string) — eyebrow label
 *   layout  (string) — 'container' or 'container-fluid' (default: 'container')
 */

$count    = isset($args['count'])    ? intval($args['count'])         : 3;
$cols     = isset($args['cols'])     ? intval($args['cols'])          : 3;
$title    = isset($args['title'])    ? sanitize_text_field($args['title'])    : 'Latest Videos';
$subtitle = isset($args['subtitle']) ? sanitize_text_field($args['subtitle']) : 'Watch';
$layout   = isset($args['layout'])   ? sanitize_text_field($args['layout'])   : 'container';

$q = new WP_Query(array(
    'post_type'      => 'surfer_video',
    'posts_per_page' => $count,
    'post_status'    => 'publish',
));

if (!$q->have_posts()) { wp_reset_postdata(); return; }
$layout_cls = $layout === 'container-fluid' ? 'breakout-full' : '';
?>
<section class="surfer-videos-module section-padding <?php echo esc_attr($layout_cls); ?>">
    <div class="<?php echo esc_attr($layout); ?>">
        <?php if ($title || $subtitle) : ?>
        <div class="text-center mb-3xl">
            <?php if ($subtitle) : ?><span class="text-uppercase text-accent mb-sm display-block"><?php echo esc_html($subtitle); ?></span><?php endif; ?>
            <?php if ($title)    : ?><h2><?php echo esc_html($title); ?></h2><?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="videos-grid grid-<?php echo esc_attr($cols); ?>">
            <?php while ($q->have_posts()) : $q->the_post();
                $vid_url  = get_post_meta(get_the_ID(), '_video_url',      true);
                $platform = get_post_meta(get_the_ID(), '_video_platform', true) ?: 'youtube';
                $duration = get_post_meta(get_the_ID(), '_video_duration', true);
                $location = get_post_meta(get_the_ID(), '_video_location', true);

                if (has_post_thumbnail()) {
                    $thumb = get_the_post_thumbnail_url(get_the_ID(), 'large');
                } elseif ($vid_url) {
                    $thumb = surfer_get_yt_thumbnail($vid_url);
                } else {
                    $thumb = '';
                }
            ?>
            <article class="video-card">
                <a href="<?php the_permalink(); ?>" class="video-card__thumb">
                    <?php if ($thumb) : ?>
                        <img src="<?php echo esc_url($thumb); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                    <?php else : ?>
                        <div class="video-card__no-thumb"></div>
                    <?php endif; ?>
                    <span class="video-play-btn" aria-label="Play video">
                        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
                    </span>
                    <?php if ($duration) : ?>
                        <span class="video-duration"><?php echo esc_html($duration); ?></span>
                    <?php endif; ?>
                    <span class="video-platform-badge video-platform-<?php echo esc_attr($platform); ?>">
                        <?php echo esc_html(ucfirst($platform)); ?>
                    </span>
                </a>
                <div class="video-card__body">
                    <h3 class="video-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <?php if ($location) : ?>
                        <span class="video-card__location">📍 <?php echo esc_html($location); ?></span>
                    <?php endif; ?>
                </div>
            </article>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>
        
        <div class="text-center" style="margin-top: 2rem;">
            <a href="<?php echo esc_url(get_post_type_archive_link('surfer_video')); ?>" class="btn btn-outline-dark">View All Videos</a>
        </div>
    </div>
</section>
