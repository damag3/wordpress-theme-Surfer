<?php
/**
 * Template Name: Contact Template
 */
get_header(); ?>

<main class="site-main section-padding">
    <div class="container">
        <div class="contact-header text-center mb-3xl">
            <span class="text-uppercase text-accent mb-sm display-block">Get in Touch</span>
            <h1 class="mb-lg">Let's Create Something <br> <span class="italic">Legendary</span>.</h1>
        </div>

        <div class="grid grid-2">
            <div class="contact-info">
                <h3 class="text-uppercase text-sm mb-lg">Contact Details</h3>
                <p class="opacity-50">I'm always open to new projects, collaborations or just a friendly chat. Feel free to reach out via the form or social media.</p>
                
                <div class="contact-methods mt-xl">
                    <div class="method mb-lg">
                        <h4 class="text-xs text-uppercase opacity-30 mb-xs">Email</h4>
                        <a href="mailto:<?php echo esc_attr(get_bloginfo('admin_email')); ?>" class="text-lg"><?php echo esc_html(get_bloginfo('admin_email')); ?></a>
                    </div>
                </div>
            </div>
            
            <div class="contact-form-wrapper">
                <?php if (have_posts()) : while (have_posts()) : the_post(); the_content(); endwhile; endif; ?>
                <!-- The user can insert a contact form shortcode here via Gutenberg -->
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>
