<?php
/**
 * Template Name: About Template
 */
get_header(); ?>

<main class="site-main section-padding">
    <div class="container">
        <div class="grid grid-2">
            <div class="about-image-wrapper">
                <div class="relative">
                    <?php if (has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail('large', array('class' => 'w-full rounded-lg')); ?>
                    <?php else : ?>
                        <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=1964" class="w-full rounded-lg" alt="About Me">
                    <?php endif; ?>
                </div>
            </div>
            <div class="about-content">
                <span class="text-uppercase text-accent mb-sm display-block">The Photographer</span>
                <h1 class="mb-xl">Capturing the <span class="text-accent italic">Unseen</span>.</h1>
                <div class="prose opacity-50">
                    <?php 
                    $options = get_option('surfer_options', array());
                    $bio_text = $options['bio_text'] ?? '';
                    if ($bio_text) {
                        echo wp_kses_post(wpautop($bio_text));
                    } else {
                        if (have_posts()) : while (have_posts()) : the_post(); the_content(); endwhile; endif;
                    }
                    ?>
                </div>
                
                <div class="about-socials mt-2xl">
                    <h4 class="text-uppercase text-sm mb-md">Follow the Journey</h4>
                    <?php get_template_part('templates/social-links'); ?>
                </div>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>
