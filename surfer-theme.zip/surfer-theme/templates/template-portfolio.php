<?php
/**
 * Template Name: Portfolio Masonry
 */
get_header(); ?>

<main class="pt-48 pb-32 container-custom">
    <header class="max-w-7xl mx-auto px-10 mb-20 surfer-fade">
        <h1 class="font-display text-7xl md:text-9xl uppercase tracking-tighter mb-8"><?php the_title(); ?></h1>
        <div class="flex gap-8 border-b border-black/5 dark:border-white/5 pb-8">
            <button class="text-[10px] uppercase tracking-[0.3em] font-bold text-primary">All</button>
            <?php 
            $cats = get_terms('portfolio_cat');
            foreach($cats as $cat) : ?>
                <button class="text-[10px] uppercase tracking-[0.3em] opacity-40 hover:opacity-100 transition-opacity"><?php echo $cat->name; ?></button>
            <?php endforeach; ?>
        </div>
    </header>

    <div class="px-5">
        <div class="masonry-grid -mx-5">
            <?php 
            $q = new WP_Query(array('post_type' => 'portfolio', 'posts_per_page' => -1));
            if ($q->have_posts()) : while ($q->have_posts()) : $q->the_post(); ?>
                <div class="masonry-item w-full md:w-1/2 lg:w-1/3 p-5 surfer-fade">
                    <article class="group relative overflow-hidden rounded-xl bg-surface">
                        <a href="<?php the_permalink(); ?>">
                            <div class="overflow-hidden">
                                <?php if (has_post_thumbnail()) the_post_thumbnail('large', array('class' => 'w-full h-auto transition-transform duration-1000 group-hover:scale-110')); ?>
                            </div>
                            <div class="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-12 text-center">
                                <div>
                                    <span class="text-white/50 text-[9px] uppercase tracking-[0.3em] block mb-2"><?php $t = get_the_terms(get_the_ID(), 'portfolio_cat'); if ($t) echo $t[0]->name; ?></span>
                                    <h3 class="text-white font-display text-2xl uppercase tracking-tighter"><?php the_title(); ?></h3>
                                </div>
                            </div>
                        </a>
                    </article>
                </div>
            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
