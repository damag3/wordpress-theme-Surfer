<?php
/**
 * Template Name: Fullscreen Hero Landing
 */
get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <section class="relative h-screen w-full overflow-hidden flex items-center justify-center">
        <div class="absolute inset-0 z-0">
            <?php if (has_post_thumbnail()) : ?>
                <?php the_post_thumbnail('full', array('class' => 'w-full h-full object-cover parallax-bg')); ?>
            <?php endif; ?>
            <div class="absolute inset-0 bg-black/50"></div>
        </div>
        
        <div class="relative z-10 text-center text-white px-10 max-w-4xl surfer-fade">
            <h1 class="font-display text-[8vw] md:text-[6vw] uppercase leading-none tracking-tighter mb-10">
                <?php the_title(); ?>
            </h1>
            <div class="prose prose-xl prose-invert opacity-70 mx-auto mb-12">
                <?php the_excerpt(); ?>
            </div>
            <a href="#content" class="inline-block animate-bounce">
                <span class="material-symbols-outlined text-4xl">expand_more</span>
            </a>
        </div>
    </section>

    <div id="content" class="py-32 container-custom">
        <div class="prose prose-2xl dark:prose-invert max-w-none surfer-fade">
            <?php the_content(); ?>
        </div>
    </div>
<?php endwhile; endif; ?>

<?php get_footer(); ?>
