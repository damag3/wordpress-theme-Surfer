<?php
/**
 * SURFER Theme Functions
 */

if ( ! defined( 'SURFER_VERSION' ) ) {
    define( 'SURFER_VERSION', '2.3.5' );
}

function surfer_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
    add_theme_support( 'customize-selective-refresh-widgets' );
    
    register_nav_menus( array(
        'primary' => 'Primary Menu',
        'footer'  => 'Footer Menu',
    ) );
}
add_action( 'after_setup_theme', 'surfer_setup' );

// Widgets Registration
function surfer_widgets_init() {
    register_sidebar( array(
        'name'          => 'Home Widget Area',
        'id'            => 'home-widgets',
        'description'   => 'Widgets that appear on the homepage.',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ) );

    for ($i = 1; $i <= 4; $i++) {
        register_sidebar( array(
            'name'          => "Footer Column $i",
            'id'            => "footer-col-$i",
            'description'   => "Content for footer column $i.",
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4>',
            'after_title'   => '</h4>',
        ) );
    }
}
add_action( 'widgets_init', 'surfer_widgets_init' );

// Includes
require get_template_directory() . '/inc/enqueue.php';
require get_template_directory() . '/inc/cpt.php';
require get_template_directory() . '/inc/helpers.php';
require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/admin-panel.php';
require get_template_directory() . '/inc/plugins.php';
require get_template_directory() . '/inc/patterns.php';

/**
 * [surfer_spots] shortcode
 * Usage: [surfer_spots count="6" cols="3" title="Surf Spots" subtitle="Discover"]
 * Can be used in any page, post or widget.
 */
function surfer_spots_shortcode($atts) {
    $a = shortcode_atts(array('count'=>6,'cols'=>3,'title'=>'Surf Spots','subtitle'=>'Discover','layout'=>'container'), $atts);
    ob_start();
    get_template_part('templates/surf-spots', null, $a);
    return ob_get_clean();
}
add_shortcode('surfer_spots', 'surfer_spots_shortcode');

function surfer_videos_shortcode($atts) {
    $a = shortcode_atts(array('count'=>3,'cols'=>3,'title'=>'Latest Videos','subtitle'=>'Watch','layout'=>'container'), $atts);
    ob_start();
    get_template_part('templates/videos', null, $a);
    return ob_get_clean();
}
add_shortcode('surfer_videos', 'surfer_videos_shortcode');
