<?php
/**
 * The template for displaying Single Portfolio Project
 */

get_header(); ?>

<?php while (have_posts()) : the_post(); ?>
    <main class="site-main">
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            


            <!-- Project Content -->
            <div class="project-content section-padding">
                <div class="container py-24 surfer-reveal-up">
                    <?php if (get_post_meta(get_the_ID(), '_surfer_show_banner', true) !== 'on') : ?>
                        <div class="text-center mb-xl">
                            <?php
                            $terms = get_the_terms(get_the_ID(), 'portfolio_cat');
                            if ($terms && !is_wp_error($terms)) :
                                echo '<span class="text-accent text-uppercase mb-sm display-block">' . esc_html($terms[0]->name) . '</span>';
                            endif;
                            ?>
                            <h1 class="page-title"><?php the_title(); ?></h1>
                        </div>
                    <?php endif; ?>
                    <?php surfer_maybe_render_spots(get_the_ID(), 'before'); ?>
                    <?php surfer_maybe_render_videos(get_the_ID(), 'before'); ?>
                    <div class="grid grid-main-sidebar">
                        <div class="project-info">
                            <div class="prose">
                                <?php the_content(); ?>
                            </div>
                        </div>
                        <div class="project-sidebar">
                            <?php get_template_part('templates/social-links', null, array('label' => 'Follow:')); ?>
                        </div>
                    </div>
                </div>
            </div>
            <?php surfer_maybe_render_spots(get_the_ID(), 'after'); ?>
            <?php surfer_maybe_render_videos(get_the_ID(), 'after'); ?>

            <!-- Project Gallery (if any) -->
            <?php 
            $gallery = get_post_meta(get_the_ID(), '_project_gallery', true);
            if ($gallery) : ?>
                <section class="project-gallery section-padding bg-gray-100">
                    <div class="container">
                        <div class="gallery-grid masonry">
                            <?php 
                            foreach($gallery as $img_id) :
                                echo '<div class="gallery-item">' . wp_get_attachment_image($img_id, 'large') . '</div>';
                            endforeach;
                            ?>
                        </div>
                    </div>
                </section>
            <?php endif; ?>

        </article>
        
        <!-- Navigation -->
        <div class="project-navigation py-xl">
            <div class="container">
                <div class="flex flex-between">
                    <div class="nav-prev"><?php previous_post_link('%link', '&larr; Previous Project'); ?></div>
                    <div class="nav-next"><?php next_post_link('%link', 'Next Project &rarr;'); ?></div>
                </div>
            </div>
        </div>
    </main>
<?php endwhile; ?>

<?php get_footer(); ?>
