<?php get_header(); ?>

<main class="pt-48 pb-32 container-custom">
    <header class="max-w-7xl mx-auto px-10 mb-20 surfer-fade">
        <h1 class="font-display text-7xl md:text-9xl uppercase tracking-tighter mb-8">
            <?php the_archive_title(); ?>
        </h1>
        <div class="prose prose-xl dark:prose-invert opacity-40">
            <?php the_archive_description(); ?>
        </div>
    </header>

    <div class="px-5">
        <div class="masonry-grid -mx-5">
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <div class="masonry-item w-full md:w-1/2 lg:w-1/3 p-5 surfer-fade">
                    <article class="group">
                        <a href="<?php the_permalink(); ?>">
                            <div class="overflow-hidden rounded-xl bg-surface shadow-lg mb-6">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail('large', array('class' => 'w-full h-auto transition-transform duration-1000 group-hover:scale-110')); ?>
                                <?php endif; ?>
                            </div>
                            <span class="text-[10px] uppercase tracking-[0.4em] text-primary block mb-3 opacity-60"><?php echo get_the_date(); ?></span>
                            <h2 class="font-display text-2xl uppercase tracking-tight"><?php the_title(); ?></h2>
                        </a>
                    </article>
                </div>
            <?php endwhile; endif; ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
