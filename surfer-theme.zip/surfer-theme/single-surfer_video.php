<?php
/**
 * Single Video Template
 */
get_header();

while (have_posts()) : the_post();
    $vid_url  = get_post_meta(get_the_ID(), '_video_url',      true);
    $platform = get_post_meta(get_the_ID(), '_video_platform', true) ?: 'youtube';
    $duration = get_post_meta(get_the_ID(), '_video_duration', true);
    $location = get_post_meta(get_the_ID(), '_video_location', true);
    $embed    = $vid_url ? surfer_get_embed_url($vid_url, $platform) : '';
    $cats     = get_the_terms(get_the_ID(), 'video_cat');
?>

<article class="single-video-page" id="post-<?php the_ID(); ?>">

    <!-- ── Full-width Embed Player ── -->
    <div class="single-video__player-wrap">
        <?php if ($embed) : ?>
        <div class="single-video__player">
            <iframe
                src="<?php echo esc_url($embed); ?>"
                title="<?php the_title_attribute(); ?>"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen
                loading="lazy"
            ></iframe>
        </div>
        <?php elseif (has_post_thumbnail()) : ?>
        <div class="single-video__fallback-thumb">
            <?php the_post_thumbnail('full'); ?>
            <p style="text-align:center;padding:1rem;opacity:0.5;">No embed URL provided.</p>
        </div>
        <?php endif; ?>
    </div>

    <!-- ── Video Info ── -->
    <div class="container single-video__meta section-padding">
        <?php surfer_maybe_render_spots(get_the_ID(), 'before'); ?>
        <?php surfer_maybe_render_videos(get_the_ID(), 'before'); ?>
        <div class="single-video__layout">

            <!-- Left: Info -->
            <div class="single-video__info">
                <?php if ($cats && !is_wp_error($cats)) : ?>
                <div class="video-cats mb-sm">
                    <?php foreach ($cats as $cat) : ?>
                        <a href="<?php echo esc_url(add_query_arg('cat', $cat->slug, get_post_type_archive_link('surfer_video'))); ?>" class="video-cat-tag"><?php echo esc_html($cat->name); ?></a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <h1 class="single-video__title"><?php the_title(); ?></h1>

                <div class="single-video__quick-meta">
                    <?php if ($location) : ?>
                        <span><strong>📍 Location:</strong> <?php echo esc_html($location); ?></span>
                    <?php endif; ?>
                    <?php if ($duration) : ?>
                        <span><strong>⏱ Duration:</strong> <?php echo esc_html($duration); ?></span>
                    <?php endif; ?>
                    <span><strong>📅</strong> <?php echo get_the_date(); ?></span>
                </div>

                <?php if (get_the_content()) : ?>
                <div class="single-video__desc prose mt-lg">
                    <?php the_content(); ?>
                </div>
                <?php endif; ?>

                <!-- Social Share -->
                <div class="mt-lg pt-lg" style="border-top:1px solid rgba(0,0,0,0.08);">
                    <?php get_template_part('templates/social-links', null, array('label' => 'Follow:')); ?>
                </div>
            </div>

            <!-- Right: Sidebar - more videos -->
            <aside class="single-video__sidebar">
                <h3 class="sidebar-title">More Videos</h3>
                <?php
                $more = new WP_Query(array(
                    'post_type'      => 'surfer_video',
                    'posts_per_page' => 6,
                    'post__not_in'   => array(get_the_ID()),
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                ));
                while ($more->have_posts()) : $more->the_post();
                    $m_url   = get_post_meta(get_the_ID(), '_video_url', true);
                    $m_dur   = get_post_meta(get_the_ID(), '_video_duration', true);
                    $m_loc   = get_post_meta(get_the_ID(), '_video_location', true);
                    $m_thumb = has_post_thumbnail()
                        ? get_the_post_thumbnail_url(get_the_ID(), 'medium')
                        : surfer_get_yt_thumbnail($m_url);
                ?>
                <a href="<?php the_permalink(); ?>" class="sidebar-video-item">
                    <div class="sidebar-video-thumb">
                        <?php if ($m_thumb) : ?>
                            <img src="<?php echo esc_url($m_thumb); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                        <?php endif; ?>
                        <span class="sidebar-play-icon">&#9654;</span>
                        <?php if ($m_dur) : ?><span class="video-duration"><?php echo esc_html($m_dur); ?></span><?php endif; ?>
                    </div>
                    <div class="sidebar-video-info">
                        <strong><?php the_title(); ?></strong>
                        <?php if ($m_loc) : ?><small>📍 <?php echo esc_html($m_loc); ?></small><?php endif; ?>
                    </div>
                </a>
                <?php endwhile; wp_reset_postdata(); ?>
                <a href="<?php echo get_post_type_archive_link('surfer_video'); ?>" class="btn btn-dark mt-lg" style="width:100%;text-align:center;">View All Videos</a>
            </aside>

        </div>
        <?php surfer_maybe_render_spots(get_the_ID(), 'after'); ?>
        <?php surfer_maybe_render_videos(get_the_ID(), 'after'); ?>
    </div>

</article>

<?php endwhile; ?>
<?php get_footer(); ?>
