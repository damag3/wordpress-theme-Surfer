<?php get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <main class="site-main section-padding">
        <div class="container">
            
            <?php surfer_maybe_render_spots(get_the_ID(), 'before'); ?>
            <?php surfer_maybe_render_videos(get_the_ID(), 'before'); ?>

            <?php if (get_post_meta(get_the_ID(), '_surfer_show_banner', true) !== 'on') : ?>
                <div class="mb-xl">
                    <span class="text-accent text-uppercase mb-sm display-block">Surf Spot Guide</span>
                    <h1 class="page-title"><?php the_title(); ?></h1>
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="mt-lg">
                            <?php the_post_thumbnail('full', array('style' => 'width:100%; height:auto; border-radius:var(--border-radius, 20px);')); ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="grid grid-main-sidebar" style="gap: var(--space-2xl);">
                <!-- Left: Info & Map -->
                <div class="spot-info-content">
                    <div class="prose mb-xl">
                        <?php the_content(); ?>
                    </div>

                <?php 
                $lat = get_post_meta(get_the_ID(), '_spot_lat', true);
                $lng = get_post_meta(get_the_ID(), '_spot_lng', true);
                if ($lat && $lng) : ?>
                    <div id="spot-map" style="width:100%; height:400px; border-radius:var(--border-radius, 20px); overflow:hidden; margin-bottom:var(--space-xl); border:1px solid var(--color-border);"></div>
                    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
                    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            var map = L.map('spot-map').setView([<?php echo $lat; ?>, <?php echo $lng; ?>], 13);
                            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                                attribution: '&copy; OpenStreetMap'
                            }).addTo(map);
                            L.marker([<?php echo $lat; ?>, <?php echo $lng; ?>]).addTo(map);
                        });
                    </script>
                <?php endif; ?>
            </div>

            <!-- Right: Technical Data Sidebar -->
            <div class="spot-technical-sidebar">
                <div class="spot-specs-card" style="position:sticky; top:120px; background:var(--color-gray-100); padding:40px; border-radius:var(--border-radius, 20px); border:1px solid var(--color-border);">
                    <h3 class="mb-lg" style="border-bottom:1px solid var(--color-border); padding-bottom:15px; text-transform:uppercase;">Spot Specs</h3>
                    <?php
                    $specs = array(
                        'Wave Type'      => get_post_meta(get_the_ID(), '_spot_wave_type', true),
                        'Bottom'         => get_post_meta(get_the_ID(), '_spot_bottom', true),
                        'Ideal Swell'    => get_post_meta(get_the_ID(), '_spot_swell', true),
                        'Swell Size'     => get_post_meta(get_the_ID(), '_spot_swell_size', true),
                        'Best Wind'      => get_post_meta(get_the_ID(), '_spot_wind', true),
                        'Tide'           => get_post_meta(get_the_ID(), '_spot_tide', true),
                        'Skill Level'    => get_post_meta(get_the_ID(), '_spot_level', true),
                        'Best Season'    => get_post_meta(get_the_ID(), '_spot_best_season', true),
                    );
                    ?>
                    <ul style="list-style:none; padding:0; margin:0;">
                    <?php foreach ($specs as $label => $val) : if (!$val) continue; ?>
                        <li style="display:flex; justify-content:space-between; align-items:center; padding:15px 0; border-bottom:1px solid var(--color-border);">
                            <span style="font-size:0.75rem; text-transform:uppercase; letter-spacing:0.1em; opacity:0.6;"><?php echo esc_html($label); ?></span>
                            <strong style="color:var(--color-accent); font-weight:700; text-align:right; max-width:60%;"><?php echo esc_html($val); ?></strong>
                        </li>
                    <?php endforeach; ?>
                    </ul>

                    <div style="margin-top:30px; padding-top:20px; border-top:1px solid var(--color-border);">
                        <p style="font-size:0.8rem; opacity:0.5; font-style:italic;">"Respect the locals and preserve nature. The ocean is for everyone."</p>
                        <div style="margin-top:20px;">
                            <?php get_template_part('templates/social-links', null, array('label' => 'Follow:')); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php surfer_maybe_render_spots(get_the_ID(), 'after'); ?>
        <?php surfer_maybe_render_videos(get_the_ID(), 'after'); ?>
    </main>
<?php endwhile; endif; ?>

<?php get_footer(); ?>
