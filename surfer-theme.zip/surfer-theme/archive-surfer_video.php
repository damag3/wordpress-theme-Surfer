<?php
/**
 * Archive Template: Videos
 * URL: /videos/
 */
get_header();

$options    = get_option('surfer_options', array());
$vids_paged = get_query_var('paged') ?: 1;

// Category filter
$current_cat = isset($_GET['cat']) ? sanitize_text_field($_GET['cat']) : 'all';
$cats        = get_terms(array('taxonomy' => 'video_cat', 'hide_empty' => true));

$args = array(
    'post_type'      => 'surfer_video',
    'posts_per_page' => 12,
    'paged'          => $vids_paged,
);
if ($current_cat !== 'all') {
    $args['tax_query'] = array(array('taxonomy' => 'video_cat', 'field' => 'slug', 'terms' => $current_cat));
}
$q = new WP_Query($args);
?>

<main class="surfer-videos-archive">

    <!-- ── Page Header ── -->
    <div class="videos-archive-header">
        <div class="container text-center">
            <span class="text-uppercase text-accent mb-sm display-block">Watch</span>
            <h1 class="videos-archive-title">Videos</h1>
            <?php
            $desc = get_option('surfer_videos_description', '');
            if ($desc) echo '<p class="videos-archive-desc">'.esc_html($desc).'</p>';
            ?>
        </div>
    </div>

    <!-- ── Category Filter ── -->
    <?php if (!empty($cats) && !is_wp_error($cats)) : ?>
    <div class="videos-filter-bar">
        <div class="container">
            <div class="videos-filter-tabs">
                <a href="<?php echo get_post_type_archive_link('surfer_video'); ?>"
                   class="filter-tab <?php echo ($current_cat === 'all') ? 'active' : ''; ?>">
                    All
                </a>
                <?php foreach ($cats as $cat) : ?>
                <a href="<?php echo add_query_arg('cat', $cat->slug, get_post_type_archive_link('surfer_video')); ?>"
                   class="filter-tab <?php echo ($current_cat === $cat->slug) ? 'active' : ''; ?>">
                    <?php echo esc_html($cat->name); ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ── Video Grid ── -->
    <div class="container section-padding">
        <?php if ($q->have_posts()) : ?>
        <div class="videos-grid">
            <?php while ($q->have_posts()) : $q->the_post();
                $vid_url  = get_post_meta(get_the_ID(), '_video_url',      true);
                $platform = get_post_meta(get_the_ID(), '_video_platform', true) ?: 'youtube';
                $duration = get_post_meta(get_the_ID(), '_video_duration', true);
                $location = get_post_meta(get_the_ID(), '_video_location', true);

                // Thumbnail: use featured image if set, else pull from YouTube
                if (has_post_thumbnail()) {
                    $thumb = get_the_post_thumbnail_url(get_the_ID(), 'large');
                } elseif ($vid_url) {
                    $thumb = surfer_get_yt_thumbnail($vid_url);
                } else {
                    $thumb = '';
                }
            ?>
            <article class="video-card" id="video-<?php the_ID(); ?>">
                <a href="<?php the_permalink(); ?>" class="video-card__thumb">
                    <?php if ($thumb) : ?>
                        <img src="<?php echo esc_url($thumb); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                    <?php else : ?>
                        <div class="video-card__no-thumb"></div>
                    <?php endif; ?>
                    <span class="video-play-btn" aria-label="Play video">
                        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg>
                    </span>
                    <?php if ($duration) : ?>
                        <span class="video-duration"><?php echo esc_html($duration); ?></span>
                    <?php endif; ?>
                    <span class="video-platform-badge video-platform-<?php echo esc_attr($platform); ?>">
                        <?php echo esc_html(ucfirst($platform)); ?>
                    </span>
                </a>
                <div class="video-card__body">
                    <h2 class="video-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <?php if ($location) : ?>
                        <span class="video-card__location">📍 <?php echo esc_html($location); ?></span>
                    <?php endif; ?>
                    <?php if (has_excerpt()) : ?>
                        <p class="video-card__desc"><?php echo wp_trim_words(get_the_excerpt(), 18); ?></p>
                    <?php endif; ?>
                    <a href="<?php the_permalink(); ?>" class="btn btn-dark video-card__btn">Watch &rarr;</a>
                </div>
            </article>
            <?php endwhile; ?>
        </div>

        <!-- Pagination -->
        <div class="videos-pagination">
            <?php echo paginate_links(array(
                'total'   => $q->max_num_pages,
                'current' => $vids_paged,
                'prev_text' => '&larr; Newer',
                'next_text' => 'Older &rarr;',
            )); ?>
        </div>

        <?php wp_reset_postdata(); else : ?>
        <div class="text-center section-padding">
            <p style="opacity:0.4;">No videos published yet. Add your first video in <strong>Videos &rarr; Add New</strong>.</p>
        </div>
        <?php endif; ?>
    </div>

</main>

<?php get_footer(); ?>
