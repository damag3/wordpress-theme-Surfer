<?php get_header(); ?>

<?php 
if ( have_posts() ) : 
    while ( have_posts() ) : the_post(); 

        $default_order  = 'hero,about,gallery,widgets,content,portfolio,surf_spots,videos,blog';
        $saved_order    = get_theme_mod('home_sections_order', $default_order);
        $saved_array    = explode(',', $saved_order);
        $master_keys    = explode(',', $default_order);
        $sections_order = array_unique(array_merge($saved_array, $master_keys));

        $options = get_option('surfer_options', array());
        $bio_opt = get_option('surfer_bio_options', array());
        
        foreach ($sections_order as $section_key) :
            
            switch ($section_key) :
                
                // ── HERO ───────────────────────────────────────────────
                case 'hero':
                    $has_slides = false;
                    for ($i = 1; $i <= 3; $i++) if (get_theme_mod("hero_image_$i")) $has_slides = true;
                    if (!$has_slides) break; // silent if no images
                    $hero_h_raw = $options['hero_height'] ?? '100vh';
                    $hero_h_map = array('h-screen' => '100vh', 'h-80vh' => '80vh', 'h-60vh' => '60vh', 'h-[50vh]' => '50vh');
                    $hero_h     = $hero_h_map[$hero_h_raw] ?? $hero_h_raw;
                    $hero_layout = $options['hero_layout'] ?? 'wide';
                    $hero_cls = $hero_layout === 'boxed' ? '' : 'breakout-full';
                    if ($hero_layout === 'boxed') $hero_cls .= ' container';
                    ?>
                    <section class="hero-section <?php echo esc_attr($hero_cls); ?>" style="height: <?php echo esc_attr($hero_h); ?>; min-height: <?php echo esc_attr($hero_h); ?>;">
                        <div class="swiper hero-swiper">
                            <div class="swiper-wrapper">
                                <?php for ($i = 1; $i <= 3; $i++) :
                                    $img       = get_theme_mod("hero_image_$i");
                                    $title     = get_theme_mod("hero_title_$i");
                                    $subtitle  = get_theme_mod("hero_subtitle_$i");
                                    $btn_txt   = get_theme_mod("hero_btn_text_$i", 'Explore');
                                    $btn_link  = get_theme_mod("hero_btn_link_$i", '#');
                                    $btn2_txt  = get_theme_mod("hero_btn2_text_$i");
                                    $btn2_link = get_theme_mod("hero_btn2_link_$i", '#');
                                    if (!$img) continue; ?>
                                    <div class="swiper-slide hero-slide">
                                        <div class="hero-bg"><img src="<?php echo esc_url($img); ?>" alt=""></div>
                                        <div class="hero-content">
                                            <?php if ($subtitle) : ?><span class="hero-subtitle"><?php echo esc_html($subtitle); ?></span><?php endif; ?>
                                            <?php if ($title)    : ?><h2 class="hero-title"><?php echo esc_html($title); ?></h2><?php endif; ?>
                                            <div class="hero-buttons">
                                                <?php if ($btn_txt) : ?>
                                                    <a href="<?php echo esc_url($btn_link); ?>" class="btn btn-white"><?php echo esc_html($btn_txt); ?></a>
                                                <?php endif; ?>
                                                <?php if ($btn2_txt) : ?>
                                                    <a href="<?php echo esc_url($btn2_link); ?>" class="btn btn-outline-white"><?php echo esc_html($btn2_txt); ?></a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <div class="swiper-pagination"></div>
                        </div>
                    </section>
                    <?php
                    break;

                // ── ABOUT ──────────────────────────────────────────────
                case 'about':
                    // Only show if enabled AND there's actual bio content
                    if (!get_theme_mod('show_about_front', true)) break;
                    $a_title = $options['bio_title']    ?? ($bio_opt['title']    ?? '');
                    $a_sub   = $options['bio_subtitle'] ?? ($bio_opt['subtitle'] ?? '');
                    $a_text  = $options['bio_text']     ?? ($bio_opt['text']     ?? '');
                    $a_img   = $options['bio_image']    ?? ($bio_opt['image']    ?? '');
                    if (!$a_title && !$a_text && !$a_img) break; // silent if empty
                    ?>
                    <section class="section-padding">
                        <div class="container grid grid-2">
                            <?php if ($a_img) : ?>
                            <div class="about-image">
                                <img src="<?php echo esc_url($a_img); ?>" class="about-img" alt="Bio">
                            </div>
                            <?php endif; ?>
                            <div class="about-content">
                                <?php if ($a_sub)   : ?><span class="text-uppercase text-accent mb-sm display-block"><?php echo esc_html($a_sub); ?></span><?php endif; ?>
                                <?php if ($a_title) : ?><h2 class="mb-lg"><?php echo esc_html($a_title); ?></h2><?php endif; ?>
                                <?php if ($a_text)  : ?><div class="prose opacity-50 mb-lg"><?php echo wp_kses_post(wpautop($a_text)); ?></div><?php endif; ?>
                                <?php get_template_part('templates/social-links'); ?>
                            </div>
                        </div>
                    </section>
                    <?php
                    break;

                // ── WIDGETS ────────────────────────────────────────────
                case 'widgets':
                    if (!is_active_sidebar('home-widgets')) break; // silent if no widgets
                    ?>
                    <section class="section-padding">
                        <div class="container grid grid-3">
                            <?php dynamic_sidebar('home-widgets'); ?>
                        </div>
                    </section>
                    <?php
                    break;

                // ── GALLERY ────────────────────────────────────────────
                case 'gallery':
                    if (!get_theme_mod('show_gallery_front', false)) break;
                    $shortcode = get_theme_mod('gallery_shortcode', '');
                    if (!$shortcode) break; // silent if no shortcode
                    $g_layout = $options['gallery_layout'] ?? 'wide';
                    $g_cls = $g_layout === 'boxed' ? '' : 'breakout-full';
                    ?>
                    <section class="section-padding <?php echo esc_attr($g_cls); ?>">
                        <div class="<?php echo $g_layout === 'boxed' ? 'container' : 'container-fluid'; ?>"><?php echo do_shortcode($shortcode); ?></div>
                    </section>
                    <?php
                    break;

                // ── PAGE CONTENT (Gutenberg) ────────────────────────────
                case 'content':
                    $content = get_the_content();
                    if (!$content) break; // silent if page has no content
                    ?>
                    <div id="page-content" class="section-padding">
                        <div class="container"><?php the_content(); ?></div>
                    </div>
                    <?php
                    break;

                // ── PORTFOLIO ──────────────────────────────────────────
                case 'portfolio':
                    // Check both Surfer Panel option and Customizer toggle
                    $show_p = ($options['show_portfolio_front'] ?? '') === 'on' || get_theme_mod('show_portfolio_front', true);
                    if (!$show_p) break;
                    $p_count = intval($options['portfolio_count'] ?? 6);
                    $p_cat   = $options['portfolio_category'] ?? 'all';
                    $p_cols  = intval($options['portfolio_cols'] ?? 3);
                    $p_layout= ($options['portfolio_layout'] ?? 'boxed') === 'wide' ? 'container-fluid' : 'container';
                    $p_args  = array('post_type' => 'portfolio', 'posts_per_page' => $p_count);
                    if ($p_cat !== 'all') $p_args['tax_query'] = array(array('taxonomy' => 'portfolio_cat', 'field' => 'slug', 'terms' => $p_cat));
                    $q = new WP_Query($p_args);
                    if (!$q->have_posts()) { wp_reset_postdata(); break; } // silent if no posts
                    $p_cls = $p_layout === 'container-fluid' ? 'breakout-full' : '';
                    ?>
                    <section class="section-padding <?php echo esc_attr($p_cls); ?>">
                        <div class="container text-center mb-3xl">
                            <span class="text-uppercase text-accent mb-sm display-block">Visual Stories</span>
                            <h2>Projects</h2>
                        </div>
                        <div class="<?php echo esc_attr($p_layout); ?>">
                            <div class="grid grid-<?php echo $p_cols; ?>">
                                <?php while ($q->have_posts()) : $q->the_post(); ?>
                                    <article class="card">
                                        <a href="<?php the_permalink(); ?>">
                                            <div class="card-image">
                                                <?php if (has_post_thumbnail()) the_post_thumbnail('large'); ?>
                                            </div>
                                            <div class="card-content">
                                                <h3 class="card-title"><?php the_title(); ?></h3>
                                            </div>
                                        </a>
                                    </article>
                                <?php endwhile; wp_reset_postdata(); ?>
                            </div>
                        </div>
                    </section>
                    <?php
                    break;

                // ── BLOG ───────────────────────────────────────────────
                case 'blog':
                    if (!get_theme_mod('show_blog_front', false)) break;
                    $b_cat = get_theme_mod('blog_cat_front', 'all');
                    $b_layout = ($options['blog_layout'] ?? 'boxed') === 'wide' ? 'container-fluid' : 'container';
                    $b_args = array('post_type' => 'post', 'posts_per_page' => 2);
                    if ($b_cat !== 'all') $b_args['category_name'] = $b_cat;
                    $bq = new WP_Query($b_args);
                    if (!$bq->have_posts()) { wp_reset_postdata(); break; } // silent if no posts
                    $b_cls = $b_layout === 'container-fluid' ? 'breakout-full' : '';
                    ?>
                    <section class="section-padding <?php echo esc_attr($b_cls); ?>">
                        <div class="<?php echo esc_attr($b_layout); ?>">
                            <h2 class="text-center mb-3xl">Journal</h2>
                            <div class="grid grid-2">
                                <?php while ($bq->have_posts()) : $bq->the_post(); ?>
                                    <article class="card">
                                        <div class="card-content">
                                            <span class="opacity-50 text-xs mb-sm display-block"><?php echo get_the_date(); ?></span>
                                            <h3 class="card-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                            <div class="opacity-50"><?php the_excerpt(); ?></div>
                                        </div>
                                    </article>
                                <?php endwhile; wp_reset_postdata(); ?>
                            </div>
                        </div>
                    </section>
                    <?php
                    break;

                // ── SURF SPOTS ─────────────────────────────────────────
                case 'surf_spots':
                    if (!get_theme_mod('show_surf_spots_front', false)) break;
                    $ss_count = intval(get_theme_mod('surf_spots_count', 6));
                    $ss_cols  = intval(get_theme_mod('surf_spots_cols', 3));
                    $ss_title = get_theme_mod('surf_spots_title', 'Surf Spots');
                    $ss_sub   = get_theme_mod('surf_spots_subtitle', 'Discover');
                    $ss_layout= ($options['surf_spots_layout'] ?? 'boxed') === 'wide' ? 'container-fluid' : 'container';
                    // Check there are spots
                    $ss_check = new WP_Query(array('post_type'=>'surf_spot','posts_per_page'=>1));
                    if (!$ss_check->have_posts()) { wp_reset_postdata(); break; }
                    wp_reset_postdata();
                    get_template_part('templates/surf-spots', null, array(
                        'count'    => $ss_count,
                        'cols'     => $ss_cols,
                        'title'    => $ss_title,
                        'subtitle' => $ss_sub,
                        'layout'   => $ss_layout,
                    ));
                    break;

                // ── VIDEOS ─────────────────────────────────────────────
                case 'videos':
                    if (!get_theme_mod('show_videos_front', false)) break;
                    $v_count = intval(get_theme_mod('videos_count', 3));
                    $v_cols  = intval(get_theme_mod('videos_cols', 3));
                    $v_title = get_theme_mod('videos_title', 'Latest Videos');
                    $v_sub   = get_theme_mod('videos_subtitle', 'Watch');
                    $v_layout= ($options['videos_layout'] ?? 'boxed') === 'wide' ? 'container-fluid' : 'container';
                    $v_check = new WP_Query(array('post_type'=>'surfer_video','posts_per_page'=>1));
                    if (!$v_check->have_posts()) { wp_reset_postdata(); break; }
                    wp_reset_postdata();
                    get_template_part('templates/videos', null, array(
                        'count'    => $v_count,
                        'cols'     => $v_cols,
                        'title'    => $v_title,
                        'subtitle' => $v_sub,
                        'layout'   => $v_layout,
                    ));
                    break;

            endswitch;
        endforeach;

    endwhile;
endif; ?>

<?php get_footer(); ?>
