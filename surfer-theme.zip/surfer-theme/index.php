<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 */

get_header(); ?>

<main class="pt-48 pb-32 container-custom">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article class="max-w-4xl mx-auto mb-40 surfer-fade">
            <header class="mb-16">
                <span class="text-[10px] uppercase tracking-[0.4em] opacity-30 block mb-4"><?php echo get_the_date('d M, Y'); ?></span>
                <h1 class="font-display text-7xl uppercase tracking-tighter leading-none mb-10"><?php the_title(); ?></h1>
            </header>
            
            <?php if (has_post_thumbnail()) : ?>
                <div class="mb-16 rounded-2xl overflow-hidden shadow-2xl">
                    <?php the_post_thumbnail('full', array('class' => 'w-full h-auto')); ?>
                </div>
            <?php endif; ?>

            <div class="prose prose-xl dark:prose-invert opacity-70 max-w-none leading-relaxed">
                <?php the_content(); ?>
            </div>
        </article>
    <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>
