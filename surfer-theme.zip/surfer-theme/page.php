<?php get_header(); ?>

<main id="primary" class="site-main">

    <?php while ( have_posts() ) : the_post(); ?>

        <?php 
        $show_banner = get_post_meta(get_the_ID(), '_surfer_show_banner', true) === 'on';
        ?>

        <article id="post-<?php the_ID(); ?>" <?php body_class(); ?>>
            
            <?php if (!$show_banner) : ?>
                <!-- Standard Title if no banner -->
                <header class="py-24 bg-surface text-center px-10">
                    <h1 class="font-display text-5xl md:text-7xl uppercase tracking-tighter"><?php the_title(); ?></h1>
                </header>
            <?php endif; ?>

            <div class="container py-24 prose prose-lg prose-stone surfer-reveal-up">
                <?php surfer_maybe_render_spots(get_the_ID(), 'before'); ?>
                <?php surfer_maybe_render_videos(get_the_ID(), 'before'); ?>
                <?php the_content(); ?>
                <div class="mt-16 pt-10 border-t border-black/5">
                    <?php get_template_part('templates/social-links', null, array('label' => 'Follow:')); ?>
                </div>
            </div>
            <?php surfer_maybe_render_spots(get_the_ID(), 'after'); ?>
            <?php surfer_maybe_render_videos(get_the_ID(), 'after'); ?>

        </article>

    <?php endwhile; ?>

</main>

<?php get_footer(); ?>
