/**
 * SURFER Theme Main JS
 */

document.addEventListener('DOMContentLoaded', () => {
    initStickyHeader();
    initMobileMenu();
    initDarkMode();
    initPageTransitions();
    initHeroSlider();
});

/**
 * Hero Slider (Swiper)
 */
function initHeroSlider() {
    const heroSwiper = new Swiper('.hero-swiper', {
        loop: true,
        speed: 1000,
        autoplay: {
            delay: 5000,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        effect: 'fade',
        fadeEffect: {
            crossFade: true
        }
    });
}

/**
 * Sticky Header Logic
 */
function initStickyHeader() {
    const header = document.querySelector('.site-header');
    if (!header) return;

    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            header.classList.add('is-sticky');
        } else {
            header.classList.remove('is-sticky');
        }
    });
}

/**
 * Mobile Menu / Fullscreen Overlay
 */
function initMobileMenu() {
    const burger = document.querySelector('.menu-toggle');
    const menu = document.querySelector('.fullscreen-nav');
    if (!burger || !menu) return;

    burger.addEventListener('click', () => {
        burger.classList.toggle('is-active');
        menu.classList.toggle('is-open');
        document.body.classList.toggle('no-scroll');
    });
}

/**
 * Dark/Light Mode Toggle
 */
function initDarkMode() {
    const toggle = document.querySelector('.theme-toggle');
    if (!toggle) return;

    toggle.addEventListener('click', () => {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    });
}

/**
 * Page Transitions (Simple Fade)
 */
function initPageTransitions() {
    const loader = document.querySelector('.page-transition-overlay');
    if (!loader) return;

    window.addEventListener('load', () => {
        loader.classList.add('is-hidden');
    });

    document.querySelectorAll('a').forEach(link => {
        if (link.hostname === window.location.hostname && 
            !link.hash && 
            link.target !== '_blank' && 
            !link.href.includes('wp-admin') &&
            !link.href.includes('wp-login')) {
            link.addEventListener('click', e => {
                e.preventDefault();
                const target = link.href;
                loader.classList.remove('is-hidden');
                setTimeout(() => {
                    window.location.href = target;
                }, 500);
            });
        }
    });
}
