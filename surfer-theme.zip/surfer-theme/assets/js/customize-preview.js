/**
 * SURFER Live Preview JS
 */
(function($) {
    // Hero Title
    wp.customize('hero_title', function(value) {
        value.bind(function(newval) {
            $('#hero-title-node').text(newval);
        });
    });

    // Portfolio Title
    wp.customize('portfolio_title', function(value) {
        value.bind(function(newval) {
            $('#portfolio-title-node').text(newval);
        });
    });

    // Hero CTA
    wp.customize('hero_cta_text', function(value) {
        value.bind(function(newval) {
            $('.surfer-fade a').text(newval);
        });
    });
})(jQuery);
