/**
 * SURFER Dashboard JS
 */

jQuery(document).ready(function($) {
    
    // Sidebar Navigation
    $('.surfer-nav a').on('click', function(e) {
        e.preventDefault();
        
        var target = $(this).attr('href');
        
        // Active Class Nav
        $('.surfer-nav a').removeClass('active');
        $(this).addClass('active');
        
        // Active Section
        $('.surfer-section').removeClass('active');
        $(target).addClass('active');
    });

    // Media Uploader
    $('.surfer-upload-button').click(function(e) {
        e.preventDefault();
        var button = $(this);
        var input = $('#' + button.data('input'));
        
        var custom_uploader = wp.media({
            title: 'Select Image',
            button: { text: 'Use Image' },
            multiple: false
        }).on('select', function() {
            var attachment = custom_uploader.state().get('selection').first().toJSON();
            input.val(attachment.url);
        }).open();
    });

});
