/**
 * SURFER Customizer Drag & Drop Handler - v1.1
 */
(function($) {
    $(document).ready(function() {
        // Initialize jQuery UI Sortable on our custom list
        $('.surfer-sortable-list').sortable({
            axis: 'y',
            cursor: 'move',
            opacity: 0.8,
            update: function(event, ui) {
                var order = [];
                $(this).find('.surfer-sortable-item').each(function() {
                    order.push($(this).data('value'));
                });
                
                // Find the hidden input and update its value
                var $input = $(this).closest('.customize-control-surfer_sortable').find('.surfer-sortable-input');
                var newValue = order.join(',');
                
                // Set value and trigger change for WordPress Customizer to detect
                $input.val(newValue).trigger('change');
                
                // Extra trigger for WP Customizer API
                var settingId = $input.data('customize-setting-link');
                if (wp.customize && wp.customize(settingId)) {
                    wp.customize(settingId).set(newValue);
                }
            }
        });
    });
})(jQuery);
