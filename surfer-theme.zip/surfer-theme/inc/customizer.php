<?php
/**
 * SURFER Live Customizer - v3.5 (Smart Reorder Fix)
 */

if (class_exists('WP_Customize_Control')) {
    class Surfer_Sortable_Control extends WP_Customize_Control {
        public $type = 'surfer_sortable';
        public function render_content() {
            // Seções mestras disponíveis
            $labels = array(
                'hero'        => '✨ Hero Slider',
                'gallery'     => '🎞️ Gallery Carousel',
                'widgets'     => '🧱 Home Widgets',
                'content'     => '📝 Page Content (Gutenberg)',
                'portfolio'   => '📸 Portfolio Grid',
                'surf_spots'  => '🌊 Surf Spots',
                'videos'      => '🎬 Videos Module',
                'blog'        => '📰 Blog / News',
                'about'       => '👤 About Us (Bio)',
            );
            
            // Valor atual guardado
            $saved_values = explode(',', $this->value());
            
            // Garantir que TODAS as seções aparecem, mesmo que não estejam no valor guardado
            $all_keys = array_keys($labels);
            $final_values = array_unique(array_merge($saved_values, $all_keys));
            ?>
            <span class="customize-control-title"><?php echo esc_html($this->label); ?></span>
            <ul class="surfer-sortable-list" style="list-style:none; padding:0; margin:0;">
                <?php foreach ($final_values as $val) : 
                    if(isset($labels[$val])): ?>
                    <li data-value="<?php echo esc_attr($val); ?>" class="surfer-sortable-item" style="background:#fff; border:1px solid #ddd; padding:12px; margin-bottom:8px; cursor:move; display:flex; align-items:center; gap:10px; border-radius:6px; box-shadow:0 2px 4px rgba(0,0,0,0.05);">
                        <span class="dashicons dashicons-menu" style="color:#aaa;"></span>
                        <?php echo esc_html($labels[$val]); ?>
                    </li>
                <?php endif; endforeach; ?>
            </ul>
            <input type="hidden" <?php $this->link(); ?> value="<?php echo esc_attr(implode(',', $final_values)); ?>" class="surfer-sortable-input" />
            <?php
        }
    }
}

function surfer_customize_register($wp_customize) {
    $sanitize_text = function($val) { return sanitize_text_field($val); };
    $sanitize_url  = function($val) { return esc_url_raw($val); };
    $sanitize_bool = function($val) { return (bool)$val; };

    $wp_customize->add_panel('surfer_home_panel', array('title' => __('Front Page Builder', 'surfer'), 'priority' => 10));

    // REORDERING (DRAG & DROP)
    $wp_customize->add_section('surfer_reorder', array('title' => __('🔄 Section Order (Drag & Drop)', 'surfer'), 'panel' => 'surfer_home_panel', 'priority' => 1));
    $wp_customize->add_setting('home_sections_order', array('default' => 'hero,about,gallery,widgets,content,portfolio,surf_spots,videos,blog', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control(new Surfer_Sortable_Control($wp_customize, 'home_sections_order', array('label' => __('Change section order:'), 'section' => 'surfer_reorder')));


    // --- RESTANTES SEÇÕES ---
    // HERO
    $wp_customize->add_section("surfer_hero_main", array('title' => __("1. Hero Slider Settings", 'surfer'), 'panel' => 'surfer_home_panel'));
    for ($i = 1; $i <= 3; $i++) {
        $wp_customize->add_section("surfer_hero_slide_$i", array('title' => __("Hero: Slide $i", 'surfer'), 'panel' => 'surfer_home_panel'));
        // Image
        $wp_customize->add_setting("hero_image_$i", array('default' => '', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_url));
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "hero_image_$i", array('label' => __("Slide $i Image", 'surfer'), 'section' => "surfer_hero_slide_$i")));
        // Title
        $wp_customize->add_setting("hero_title_$i", array('default' => '', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
        $wp_customize->add_control("hero_title_$i", array('label' => __("Slide $i Title", 'surfer'), 'section' => "surfer_hero_slide_$i"));
        // Subtitle
        $wp_customize->add_setting("hero_subtitle_$i", array('default' => '', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
        $wp_customize->add_control("hero_subtitle_$i", array('label' => __("Slide $i Subtitle (optional)", 'surfer'), 'section' => "surfer_hero_slide_$i"));
        // Button 1
        $wp_customize->add_setting("hero_btn_text_$i", array('default' => 'Explore', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
        $wp_customize->add_control("hero_btn_text_$i", array('label' => __("Button 1 Text", 'surfer'), 'section' => "surfer_hero_slide_$i"));
        $wp_customize->add_setting("hero_btn_link_$i", array('default' => '#', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_url));
        $wp_customize->add_control("hero_btn_link_$i", array('label' => __("Button 1 Link", 'surfer'), 'section' => "surfer_hero_slide_$i"));
        // Button 2 (optional)
        $wp_customize->add_setting("hero_btn2_text_$i", array('default' => '', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
        $wp_customize->add_control("hero_btn2_text_$i", array('label' => __("Button 2 Text (optional)", 'surfer'), 'section' => "surfer_hero_slide_$i"));
        $wp_customize->add_setting("hero_btn2_link_$i", array('default' => '#', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_url));
        $wp_customize->add_control("hero_btn2_link_$i", array('label' => __("Button 2 Link", 'surfer'), 'section' => "surfer_hero_slide_$i"));
    }

    // PORTFOLIO
    $wp_customize->add_section('surfer_portfolio_edit', array('title' => __('2. Portfolio Section', 'surfer'), 'panel' => 'surfer_home_panel'));
    $wp_customize->add_setting('show_portfolio_front', array('default' => true, 'transport' => 'refresh', 'sanitize_callback' => $sanitize_bool));
    $wp_customize->add_control('show_portfolio_front', array('label' => __('Show Portfolio', 'surfer'), 'section' => 'surfer_portfolio_edit', 'type' => 'checkbox'));
    $wp_customize->add_setting('portfolio_count_front', array('default' => '6', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('portfolio_count_front', array('label' => __('Number of Projects', 'surfer'), 'section' => 'surfer_portfolio_edit', 'type' => 'number'));
    $portfolio_cats = array('all' => 'All Categories');
    $p_terms = get_terms(array('taxonomy' => 'portfolio_cat', 'hide_empty' => false));
    if (!is_wp_error($p_terms)) foreach($p_terms as $t) $portfolio_cats[$t->slug] = $t->name;
    $wp_customize->add_setting('portfolio_cat_front', array('default' => 'all', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('portfolio_cat_front', array('label' => __('Filter Category', 'surfer'), 'section' => 'surfer_portfolio_edit', 'type' => 'select', 'choices' => $portfolio_cats));
    $wp_customize->add_setting('portfolio_layout_front', array('default' => 'container', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('portfolio_layout_front', array('label' => __('Layout', 'surfer'), 'section' => 'surfer_portfolio_edit', 'type' => 'select', 'choices' => array('container' => 'Boxed (Container)', 'container-fluid' => 'Wide (Full Width)')));

    // BLOG
    $wp_customize->add_section('surfer_blog_edit', array('title' => __('3. Blog / News Section', 'surfer'), 'panel' => 'surfer_home_panel'));
    $wp_customize->add_setting('show_blog_front', array('default' => false, 'transport' => 'refresh', 'sanitize_callback' => $sanitize_bool));
    $wp_customize->add_control('show_blog_front', array('label' => __('Show Blog', 'surfer'), 'section' => 'surfer_blog_edit', 'type' => 'checkbox'));
    $blog_cats = array('all' => 'All Categories');
    $b_terms = get_categories();
    foreach($b_terms as $t) $blog_cats[$t->slug] = $t->name;
    $wp_customize->add_setting('blog_cat_front', array('default' => 'all', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('blog_cat_front', array('label' => __('Filter Blog Category', 'surfer'), 'section' => 'surfer_blog_edit', 'type' => 'select', 'choices' => $blog_cats));
    $wp_customize->add_setting('blog_layout_front', array('default' => 'container', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('blog_layout_front', array('label' => __('Layout', 'surfer'), 'section' => 'surfer_blog_edit', 'type' => 'select', 'choices' => array('container' => 'Boxed (Container)', 'container-fluid' => 'Wide (Full Width)')));

    // GALLERY
    $wp_customize->add_section('surfer_gallery_edit', array('title' => __('4. Gallery Carousel', 'surfer'), 'panel' => 'surfer_home_panel'));
    $wp_customize->add_setting('show_gallery_front', array('default' => false, 'transport' => 'refresh', 'sanitize_callback' => $sanitize_bool));
    $wp_customize->add_control('show_gallery_front', array('label' => __('Show Carousel', 'surfer'), 'section' => 'surfer_gallery_edit', 'type' => 'checkbox'));
    $wp_customize->add_setting('gallery_width', array('default' => 'max-w-7xl', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('gallery_width', array('label' => __('Gallery Size', 'surfer'), 'section' => 'surfer_gallery_edit', 'type' => 'select', 'choices' => array('max-w-7xl' => 'Contained', 'max-w-[1400px]' => 'Wide', 'max-w-full' => 'Full Screen')));
    $wp_customize->add_setting('gallery_shortcode', array('default' => '', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('gallery_shortcode', array('label' => __('Plugin Shortcode', 'surfer'), 'section' => 'surfer_gallery_edit'));
	
    // ABOUT US SECTION (Visibility Control)
    $wp_customize->add_section('surfer_about_edit', array('title' => __('5. About Us (Bio)', 'surfer'), 'panel' => 'surfer_home_panel'));
    $wp_customize->add_setting('show_about_front', array('default' => true, 'transport' => 'refresh', 'sanitize_callback' => $sanitize_bool));
    $wp_customize->add_control('show_about_front', array('label' => __('Show About Us section on Home', 'surfer'), 'section' => 'surfer_about_edit', 'type' => 'checkbox'));

    // SURF SPOTS SECTION
    $wp_customize->add_section('surfer_spots_edit', array('title' => __('6. Surf Spots Module', 'surfer'), 'panel' => 'surfer_home_panel', 'description' => 'Display a grid of surf spots on the front page. You can also use [surfer_spots] shortcode on any page or post.'));
    $wp_customize->add_setting('show_surf_spots_front', array('default' => false, 'transport' => 'refresh', 'sanitize_callback' => $sanitize_bool));
    $wp_customize->add_control('show_surf_spots_front', array('label' => __('Show Surf Spots on Front Page', 'surfer'), 'section' => 'surfer_spots_edit', 'type' => 'checkbox'));
    $wp_customize->add_setting('surf_spots_count', array('default' => '6', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('surf_spots_count', array('label' => __('Number of Spots', 'surfer'), 'section' => 'surfer_spots_edit', 'type' => 'number'));
    $wp_customize->add_setting('surf_spots_cols', array('default' => '3', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('surf_spots_cols', array('label' => __('Grid Columns', 'surfer'), 'section' => 'surfer_spots_edit', 'type' => 'select', 'choices' => array('2' => '2 Columns', '3' => '3 Columns', '4' => '4 Columns')));
    $wp_customize->add_setting('surf_spots_title', array('default' => 'Surf Spots', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('surf_spots_title', array('label' => __('Section Title', 'surfer'), 'section' => 'surfer_spots_edit'));
    $wp_customize->add_setting('surf_spots_subtitle', array('default' => 'Discover', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('surf_spots_subtitle', array('label' => __('Eyebrow Label (above title)', 'surfer'), 'section' => 'surfer_spots_edit'));
    $wp_customize->add_setting('surf_spots_layout_front', array('default' => 'container', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('surf_spots_layout_front', array('label' => __('Layout', 'surfer'), 'section' => 'surfer_spots_edit', 'type' => 'select', 'choices' => array('container' => 'Boxed (Container)', 'container-fluid' => 'Wide (Full Width)')));

    // VIDEOS SECTION
    $wp_customize->add_section('surfer_videos_edit', array('title' => __('7. Videos Module', 'surfer'), 'panel' => 'surfer_home_panel', 'description' => 'Display a grid of videos on the front page.'));
    $wp_customize->add_setting('show_videos_front', array('default' => false, 'transport' => 'refresh', 'sanitize_callback' => $sanitize_bool));
    $wp_customize->add_control('show_videos_front', array('label' => __('Show Videos on Front Page', 'surfer'), 'section' => 'surfer_videos_edit', 'type' => 'checkbox'));
    $wp_customize->add_setting('videos_count', array('default' => '3', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('videos_count', array('label' => __('Number of Videos', 'surfer'), 'section' => 'surfer_videos_edit', 'type' => 'number'));
    $wp_customize->add_setting('videos_cols', array('default' => '3', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('videos_cols', array('label' => __('Grid Columns', 'surfer'), 'section' => 'surfer_videos_edit', 'type' => 'select', 'choices' => array('2' => '2 Columns', '3' => '3 Columns', '4' => '4 Columns')));
    $wp_customize->add_setting('videos_title', array('default' => 'Latest Videos', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('videos_title', array('label' => __('Section Title', 'surfer'), 'section' => 'surfer_videos_edit'));
    $wp_customize->add_setting('videos_subtitle', array('default' => 'Watch', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('videos_subtitle', array('label' => __('Eyebrow Label (above title)', 'surfer'), 'section' => 'surfer_videos_edit'));
    $wp_customize->add_setting('videos_layout_front', array('default' => 'container', 'transport' => 'refresh', 'sanitize_callback' => $sanitize_text));
    $wp_customize->add_control('videos_layout_front', array('label' => __('Layout', 'surfer'), 'section' => 'surfer_videos_edit', 'type' => 'select', 'choices' => array('container' => 'Boxed (Container)', 'container-fluid' => 'Wide (Full Width)')));
}
add_action('customize_register', 'surfer_customize_register');

function surfer_customizer_control_scripts() {
    wp_enqueue_script('surfer-customizer-sortable', get_template_directory_uri() . '/assets/js/customizer-sortable.js', array('jquery', 'jquery-ui-sortable'), '1.1', true);
}
add_action('customize_controls_enqueue_scripts', 'surfer_customizer_control_scripts');
