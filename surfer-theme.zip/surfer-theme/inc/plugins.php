<?php
/**
 * SURFER Required Plugins Activation (TGM)
 */

require_once get_template_directory() . '/inc/class-tgm-plugin-activation.php';

function surfer_register_required_plugins() {
    $plugins = array(
        array(
            'name'      => 'One Click Demo Import',
            'slug'      => 'one-click-demo-import',
            'required'  => true,
        ),
        array(
            'name'      => 'Contact Form 7',
            'slug'      => 'contact-form-7',
            'required'  => false,
        ),
        array(
            'name'      => 'Advanced Custom Fields',
            'slug'      => 'advanced-custom-fields',
            'required'  => true,
        ),
        array(
            'name'      => 'Smart Slider 3',
            'slug'      => 'smart-slider-3',
            'required'  => false,
        ),
        array(
            'name'      => 'Kadence Blocks – Gutenberg Page Builder Features',
            'slug'      => 'kadence-blocks',
            'required'  => false,
        ),
        array(
            'name'      => 'SVG Support',
            'slug'      => 'svg-support',
            'required'  => false,
        ),
    );

    $config = array(
        'id'           => 'surfer',
        'default_path' => '',
        'menu'         => 'tgmpa-install-plugins',
        'has_notices'  => true,
        'dismissable'  => true,
        'dismiss_msg'  => '',
        'is_automatic' => true,
        'message'      => '',
    );

    tgmpa($plugins, $config);
}
add_action('tgmpa_register', 'surfer_register_required_plugins');
