<?php
/**
 * SURFER Block Patterns - Expanded for Visual Storytelling
 */

function surfer_register_patterns() {
    register_block_pattern_category('surfer', array('label' => __('Surfer Theme', 'surfer')));

    // 1. SURFER HERO PATTERN
    register_block_pattern('surfer/hero', array(
        'title'       => __('Surfer Cinematic Hero', 'surfer'),
        'categories'  => array('surfer'),
        'content'     => '<!-- wp:group {"tagName":"section","className":"hero-section"} -->
                          <section class="wp-block-group hero-section">
                          <div class="hero-bg"><!-- wp:image {"sizeSlug":"full"} -->
                          <figure class="wp-block-image size-full"><img src="https://images.unsplash.com/photo-1502680390469-be75c86b636f" alt=""/></figure>
                          <!-- /wp:image --></div>
                          <div class="hero-content">
                          <!-- wp:heading {"level":1,"className":"hero-title"} -->
                          <h1 class="hero-title">Endless Summer</h1>
                          <!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
                          <div class="wp-block-buttons"><!-- wp:button {"className":"btn btn-white"} -->
                          <div class="wp-block-button btn btn-white"><a class="wp-block-button__link wp-element-button">View Gallery</a></div>
                          <!-- /wp:button --></div>
                          </div></section>
                          <!-- /wp:group -->',
    ));

    // 2. SURFER TESTIMONIALS
    register_block_pattern('surfer/testimonials', array(
        'title'       => __('Surfer Testimonials', 'surfer'),
        'categories'  => array('surfer'),
        'content'     => '<!-- wp:group {"className":"section-padding"} -->
                          <div class="wp-block-group section-padding">
                          <!-- wp:heading {"textAlign":"center","className":"text-uppercase mb-3xl"} -->
                          <h2 class="has-text-align-center text-uppercase mb-3xl">What Clients Say</h2>
                          <!-- wp:columns {"className":"container grid grid-3"} -->
                          <div class="wp-block-columns container grid grid-3">
                          <!-- wp:column -->
                          <div class="wp-block-column"><!-- wp:paragraph {"className":"opacity-50 italic"} -->
                          <p class="opacity-50 italic">"The shots captured the essence of the moment perfectly. Truly professional."</p>
                          <!-- wp:paragraph {"className":"text-accent font-bold mt-md"} -->
                          <p class="text-accent font-bold mt-md">- John Doe</p></div>
                          <!-- /wp:column -->
                          <!-- wp:column -->
                          <div class="wp-block-column"><!-- wp:paragraph {"className":"opacity-50 italic"} -->
                          <p class="opacity-50 italic">"Amazing work. The lighting and composition are out of this world."</p>
                          <!-- wp:paragraph {"className":"text-accent font-bold mt-md"} -->
                          <p class="text-accent font-bold mt-md">- Jane Smith</p></div>
                          <!-- /wp:column -->
                          <!-- wp:column -->
                          <div class="wp-block-column"><!-- wp:paragraph {"className":"opacity-50 italic"} -->
                          <p class="opacity-50 italic">"The best photography experience I have ever had. Highly recommended!"</p>
                          <!-- wp:paragraph {"className":"text-accent font-bold mt-md"} -->
                          <p class="text-accent font-bold mt-md">- Michael Ross</p></div>
                          <!-- /wp:column -->
                          </div><!-- /wp:columns --></div>
                          <!-- /wp:group -->',
    ));

    // 3. SURFER PRICING
    register_block_pattern('surfer/pricing', array(
        'title'       => __('Surfer Pricing Tables', 'surfer'),
        'categories'  => array('surfer'),
        'content'     => '<!-- wp:group {"className":"section-padding bg-gray-100"} -->
                          <div class="wp-block-group section-padding bg-gray-100">
                          <!-- wp:heading {"textAlign":"center","className":"text-uppercase mb-3xl"} -->
                          <h2 class="has-text-align-center text-uppercase mb-3xl">Our Packages</h2>
                          <!-- wp:columns {"className":"container grid grid-3"} -->
                          <div class="wp-block-columns container grid grid-3">
                          <!-- wp:column {"className":"card"} -->
                          <div class="wp-block-column card"><div class="card-content">
                          <!-- wp:heading {"level":3,"textAlign":"center"} -->
                          <h3 class="has-text-align-center">Basic</h3>
                          <!-- wp:paragraph {"textAlign":"center","className":"text-4xl font-bold mb-md"} -->
                          <p class="has-text-align-center text-4xl font-bold mb-md">$299</p>
                          <!-- wp:list {"className":"opacity-50 mb-xl"} -->
                          <ul class="opacity-50 mb-xl"><li>2 Hours Session</li><li>10 Digital Photos</li><li>Online Gallery</li></ul>
                          <!-- /wp:list -->
                          <!-- wp:button {"width":100,"className":"btn btn-primary"} -->
                          <div class="wp-block-button has-custom-width wp-block-button__width-100 btn btn-primary"><a class="wp-block-button__link wp-element-button">Book Now</a></div>
                          <!-- /wp:button --></div></div><!-- /wp:column -->
                          </div><!-- /wp:columns --></div>
                          <!-- /wp:group -->',
    ));
}
add_action('init', 'surfer_register_patterns');
