<?php
/**
 * Configuration for One Click Demo Import (OCDI) plugin
 */

function surfer_import_files() {
    return array(
        array(
            'import_file_name'             => 'Surfer Main Demo',
            'categories'                   => array( 'Photography', 'Portfolio' ),
            'local_import_file'            => get_template_directory() . '/inc/demo-content.xml',
            'local_import_widget_file'     => get_template_directory() . '/inc/widgets.wie',
            'local_import_customizer_file' => get_template_directory() . '/inc/customizer.dat',
            'import_preview_image_url'     => 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?w=600',
            'import_notice'                => __( 'After you import this demo, you will have a full site ready to customize.', 'surfer' ),
            'preview_url'                  => 'https://alvarofr.pt',
        ),
    );
}
add_filter( 'ocdi/import_files', 'surfer_import_files' );

function surfer_after_import_setup() {
    // Assign menus to their locations.
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
    set_theme_mod( 'nav_menu_locations', array(
            'primary' => $main_menu->term_id,
        )
    );

    // Assign front page and posts page (blog).
    $front_page_id = get_page_by_title( 'Home' );
    $blog_page_id  = get_page_by_title( 'Blog' );

    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $front_page_id->ID );
    update_option( 'page_for_posts', $blog_page_id->ID );

}
add_action( 'ocdi/after_import', 'surfer_after_import_setup' );
