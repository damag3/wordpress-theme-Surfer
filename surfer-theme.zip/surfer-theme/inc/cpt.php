<?php
/**
 * SURFER Custom Post Types & Meta Boxes
 */

function surfer_register_cpts() {
    // 1. PORTFOLIO
    register_post_type('portfolio', array(
        'labels' => array(
            'name' => 'Portfolio', 
            'singular_name' => 'Project',
            'add_new' => 'Add New Project',
            'edit_item' => 'Edit Project'
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-camera',
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'portfolio'),
    ));

    // 2. GALLERY
    register_post_type('gallery', array(
        'labels' => array(
            'name' => 'Galleries', 
            'singular_name' => 'Gallery',
            'add_new' => 'Add New Gallery',
            'edit_item' => 'Edit Gallery'
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-images-alt2',
        'supports' => array('title', 'editor', 'thumbnail'),
        'show_in_rest' => true,
        'rewrite' => array('slug' => 'galleries'),
    ));

    // 3. SURF SPOTS
    register_post_type('surf_spot', array(
        'labels' => array('name' => 'Surf Spots', 'singular_name' => 'Spot'),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-location',
        'supports' => array('title', 'editor', 'thumbnail'),
        'show_in_rest' => true,
    ));

    // 4. VIDEO
    register_post_type('surfer_video', array(
        'labels' => array(
            'name'          => 'Videos',
            'singular_name' => 'Video',
            'add_new'       => 'Add New Video',
            'edit_item'     => 'Edit Video',
            'all_items'     => 'All Videos',
        ),
        'public'       => true,
        'has_archive'  => true,
        'menu_icon'    => 'dashicons-video-alt3',
        'supports'     => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest' => true,
        'rewrite'      => array('slug' => 'videos'),
    ));

    // TAXONOMIES
    register_taxonomy('portfolio_cat', 'portfolio', array(
        'label' => 'Project Categories',
        'hierarchical' => true,
        'show_in_rest' => true,
    ));

    register_taxonomy('gallery_cat', 'gallery', array(
        'label' => 'Gallery Categories',
        'hierarchical' => true,
        'show_in_rest' => true,
    ));

    register_taxonomy('video_cat', 'surfer_video', array(
        'label'        => 'Video Categories',
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite'      => array('slug' => 'video-category'),
    ));
}
add_action('init', 'surfer_register_cpts');

/**
 * VIDEO META BOX
 */
function surfer_add_video_metabox() {
    add_meta_box('surfer_video_details', '🎬 Video Details', 'surfer_video_metabox_callback', 'surfer_video', 'normal', 'high');
}
add_action('add_meta_boxes', 'surfer_add_video_metabox');

function surfer_video_metabox_callback($post) {
    $url      = get_post_meta($post->ID, '_video_url',       true);
    $platform = get_post_meta($post->ID, '_video_platform',  true) ?: 'youtube';
    $duration = get_post_meta($post->ID, '_video_duration',  true);
    $location = get_post_meta($post->ID, '_video_location',  true);
    wp_nonce_field('surfer_video_nonce', 'surfer_video_nonce_field');
    ?>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:10px;">
        <div style="grid-column:1/-1;">
            <label><strong>Video URL</strong></label><br>
            <input type="url" name="video_url" value="<?php echo esc_attr($url); ?>" class="widefat" placeholder="https://www.youtube.com/watch?v=...">
            <p style="font-size:11px;color:#888;margin-top:4px;">Paste the full YouTube, Vimeo or other video URL. YouTube watch links and short links (youtu.be) are both supported.</p>
        </div>
        <p>
            <label><strong>Platform</strong></label><br>
            <select name="video_platform" style="width:100%;">
                <option value="youtube" <?php selected($platform,'youtube'); ?>>YouTube</option>
                <option value="vimeo"   <?php selected($platform,'vimeo'); ?>>Vimeo</option>
                <option value="other"   <?php selected($platform,'other'); ?>>Other (embed URL)</option>
            </select>
        </p>
        <p>
            <label><strong>Duration</strong></label><br>
            <input type="text" name="video_duration" value="<?php echo esc_attr($duration); ?>" style="width:100%;" placeholder="e.g. 4:32">
        </p>
        <p>
            <label><strong>Location / Spot</strong></label><br>
            <input type="text" name="video_location" value="<?php echo esc_attr($location); ?>" style="width:100%;" placeholder="e.g. Nazaré, Portugal">
        </p>
    </div>
    <?php
}

function surfer_save_video_meta($post_id) {
    if (!isset($_POST['surfer_video_nonce_field']) || !wp_verify_nonce($_POST['surfer_video_nonce_field'], 'surfer_video_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    $fields = array('video_url', 'video_platform', 'video_duration', 'video_location');
    foreach ($fields as $f) {
        if (isset($_POST[$f])) update_post_meta($post_id, '_'.$f, sanitize_text_field($_POST[$f]));
    }
}
add_action('save_post_surfer_video', 'surfer_save_video_meta');

/**
 * Helper: convert YouTube / Vimeo watch URL → embed URL
 */
function surfer_get_embed_url($url, $platform = 'youtube') {
    if ($platform === 'youtube' || strpos($url, 'youtube') !== false || strpos($url, 'youtu.be') !== false) {
        preg_match('/(?:v=|youtu\.be\/|embed\/)([A-Za-z0-9_\-]{11})/', $url, $m);
        return !empty($m[1]) ? 'https://www.youtube.com/embed/' . $m[1] . '?rel=0&modestbranding=1' : $url;
    }
    if ($platform === 'vimeo' || strpos($url, 'vimeo') !== false) {
        preg_match('/vimeo\.com\/(\d+)/', $url, $m);
        return !empty($m[1]) ? 'https://player.vimeo.com/video/' . $m[1] . '?title=0&byline=0&portrait=0' : $url;
    }
    return $url; // other: use as-is
}

/**
 * Helper: get YouTube thumbnail from URL
 */
function surfer_get_yt_thumbnail($url) {
    preg_match('/(?:v=|youtu\.be\/|embed\/)([A-Za-z0-9_\-]{11})/', $url, $m);
    return !empty($m[1]) ? 'https://img.youtube.com/vi/' . $m[1] . '/maxresdefault.jpg' : '';
}

/**
 * Meta Boxes for Surf Spots (Technical Info)
 */
function surfer_add_spot_metaboxes() {
    add_meta_box('surfer_spot_details', 'Spot Technical Info', 'surfer_spot_metabox_callback', 'surf_spot', 'normal', 'high');
}
add_action('add_meta_boxes', 'surfer_add_spot_metaboxes');



function surfer_spot_metabox_callback($post) {
    $lat      = get_post_meta($post->ID, '_spot_lat', true);
    $lng      = get_post_meta($post->ID, '_spot_lng', true);
    $swell    = get_post_meta($post->ID, '_spot_swell', true);
    $wind     = get_post_meta($post->ID, '_spot_wind', true);
    $wave     = get_post_meta($post->ID, '_spot_wave_type', true);
    $bottom   = get_post_meta($post->ID, '_spot_bottom', true);
    $tide     = get_post_meta($post->ID, '_spot_tide', true);
    $swell_sz = get_post_meta($post->ID, '_spot_swell_size', true);
    $level    = get_post_meta($post->ID, '_spot_level', true);
    $season   = get_post_meta($post->ID, '_spot_best_season', true);
    wp_nonce_field('surfer_spot_nonce', 'surfer_spot_nonce_field');
    ?>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:10px;">
        <p><label><strong>Latitude</strong></label><br>
            <input type="text" name="spot_lat" value="<?php echo esc_attr($lat); ?>" class="widefat" placeholder="38.7169"></p>
        <p><label><strong>Longitude</strong></label><br>
            <input type="text" name="spot_lng" value="<?php echo esc_attr($lng); ?>" class="widefat" placeholder="-9.1399"></p>
        <p><label><strong>Wave Type</strong></label><br>
            <select name="spot_wave_type" class="widefat">
                <option value="" <?php selected($wave, ''); ?>>— Select —</option>
                <option value="Beach Break" <?php selected($wave, 'Beach Break'); ?>>Beach Break</option>
                <option value="Reef Break" <?php selected($wave, 'Reef Break'); ?>>Reef Break</option>
                <option value="Point Break" <?php selected($wave, 'Point Break'); ?>>Point Break</option>
                <option value="River Mouth" <?php selected($wave, 'River Mouth'); ?>>River Mouth</option>
                <option value="Close-out" <?php selected($wave, 'Close-out'); ?>>Close-out</option>
            </select></p>
        <p><label><strong>Bottom Type</strong></label><br>
            <select name="spot_bottom" class="widefat">
                <option value="" <?php selected($bottom, ''); ?>>— Select —</option>
                <option value="Sand" <?php selected($bottom, 'Sand'); ?>>Sand</option>
                <option value="Rock" <?php selected($bottom, 'Rock'); ?>>Rock</option>
                <option value="Reef" <?php selected($bottom, 'Reef'); ?>>Reef (Coral)</option>
                <option value="Mixed" <?php selected($bottom, 'Mixed'); ?>>Mixed</option>
                <option value="Pebble" <?php selected($bottom, 'Pebble'); ?>>Pebble</option>
            </select></p>
        <p><label><strong>Ideal Swell Direction &amp; Size</strong></label><br>
            <input type="text" name="spot_swell" value="<?php echo esc_attr($swell); ?>" class="widefat" placeholder="e.g. NW / W, 1-3m"></p>
        <p><label><strong>Swell Size Range</strong></label><br>
            <input type="text" name="spot_swell_size" value="<?php echo esc_attr($swell_sz); ?>" class="widefat" placeholder="e.g. 0.5m – 3m"></p>
        <p><label><strong>Ideal Wind Direction</strong></label><br>
            <input type="text" name="spot_wind" value="<?php echo esc_attr($wind); ?>" class="widefat" placeholder="e.g. E / SE (Offshore)"></p>
        <p><label><strong>Tide Conditions</strong></label><br>
            <select name="spot_tide" class="widefat">
                <option value="" <?php selected($tide, ''); ?>>— Select —</option>
                <option value="All Tides" <?php selected($tide, 'All Tides'); ?>>All Tides</option>
                <option value="Low Tide" <?php selected($tide, 'Low Tide'); ?>>Low Tide</option>
                <option value="Mid Tide" <?php selected($tide, 'Mid Tide'); ?>>Mid Tide</option>
                <option value="High Tide" <?php selected($tide, 'High Tide'); ?>>High Tide</option>
                <option value="Low to Mid" <?php selected($tide, 'Low to Mid'); ?>>Low to Mid</option>
                <option value="Mid to High" <?php selected($tide, 'Mid to High'); ?>>Mid to High</option>
            </select></p>
        <p><label><strong>Skill Level Required</strong></label><br>
            <select name="spot_level" class="widefat">
                <option value="" <?php selected($level, ''); ?>>— Select —</option>
                <option value="Beginner" <?php selected($level, 'Beginner'); ?>>Beginner</option>
                <option value="Beginner / Intermediate" <?php selected($level, 'Beginner / Intermediate'); ?>>Beginner / Intermediate</option>
                <option value="Intermediate" <?php selected($level, 'Intermediate'); ?>>Intermediate</option>
                <option value="Intermediate / Advanced" <?php selected($level, 'Intermediate / Advanced'); ?>>Intermediate / Advanced</option>
                <option value="Advanced" <?php selected($level, 'Advanced'); ?>>Advanced</option>
                <option value="Expert / Pro" <?php selected($level, 'Expert / Pro'); ?>>Expert / Pro</option>
            </select></p>
        <p><label><strong>Best Season</strong></label><br>
            <input type="text" name="spot_best_season" value="<?php echo esc_attr($season); ?>" class="widefat" placeholder="e.g. Autumn / Winter"></p>
    </div>
    <?php
}

function surfer_save_spot_meta($post_id) {
    if (!isset($_POST['surfer_spot_nonce_field']) || !wp_verify_nonce($_POST['surfer_spot_nonce_field'], 'surfer_spot_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    $fields = array(
        'spot_lat', 'spot_lng', 'spot_swell', 'spot_wind',
        'spot_wave_type', 'spot_bottom', 'spot_tide',
        'spot_swell_size', 'spot_level', 'spot_best_season',
    );
    foreach ($fields as $field) {
        if (isset($_POST[$field])) update_post_meta($post_id, '_'.$field, sanitize_text_field($_POST[$field]));
    }
}
add_action('save_post', 'surfer_save_spot_meta');

/**
 * PAGE BANNER META BOX
 */
function surfer_add_banner_metabox() {
    add_meta_box('surfer_page_banner', 'Surfer: Page Banner', 'surfer_banner_metabox_callback', array('page', 'post', 'portfolio', 'surf_spot', 'surfer_video'), 'normal', 'high');
}
add_action('add_meta_boxes', 'surfer_add_banner_metabox');

function surfer_banner_metabox_callback($post) {
    $banner_img   = get_post_meta($post->ID, '_surfer_banner_image', true);
    $banner_h     = get_post_meta($post->ID, '_surfer_banner_height', true);
    $banner_layout= get_post_meta($post->ID, '_surfer_banner_layout', true) ?: 'wide';
    $show_banner  = get_post_meta($post->ID, '_surfer_show_banner', true);
    wp_nonce_field('surfer_banner_nonce', 'surfer_banner_nonce_field');
    ?>
    <div style="padding:10px;">
        <p><label><input type="checkbox" name="surfer_show_banner" <?php checked($show_banner, 'on'); ?> value="on"> <strong>Enable Banner on this page</strong></label></p>
        <p>
            <label>Banner Image:</label><br>
            <input type="text" name="surfer_banner_image" id="surfer_banner_image" value="<?php echo esc_attr($banner_img); ?>" style="width:70%;">
            <button type="button" class="button surfer-upload-banner">Upload</button>
        </p>
        <p>
            <label>Banner Height (e.g. 50vh, 300px, 100%):</label><br>
            <input type="text" name="surfer_banner_height" value="<?php echo esc_attr($banner_h ?: '60vh'); ?>" style="width:100%;" placeholder="60vh">
        </p>
        <p>
            <label>Banner Layout:</label><br>
            <select name="surfer_banner_layout" style="width:100%;">
                <option value="wide" <?php selected($banner_layout, 'wide'); ?>>Wide (Full Width)</option>
                <option value="boxed" <?php selected($banner_layout, 'boxed'); ?>>Boxed (Container)</option>
            </select>
        </p>
    </div>
    <script>
        jQuery(document).ready(function($){
            $('.surfer-upload-banner').on('click', function(e) {
                e.preventDefault();
                var image = wp.media({ title: 'Upload Banner', multiple: false }).open().on('select', function(e){
                    var uploaded_image = image.state().get('selection').first();
                    var image_url = uploaded_image.toJSON().url;
                    $('#surfer_banner_image').val(image_url);
                });
            });
        });
    </script>
    <?php
}

function surfer_save_banner_meta($post_id) {
    if (!isset($_POST['surfer_banner_nonce_field']) || !wp_verify_nonce($_POST['surfer_banner_nonce_field'], 'surfer_banner_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    
    update_post_meta($post_id, '_surfer_show_banner', $_POST['surfer_show_banner'] ?? '');
    update_post_meta($post_id, '_surfer_banner_image', sanitize_text_field($_POST['surfer_banner_image']));
    update_post_meta($post_id, '_surfer_banner_height', sanitize_text_field($_POST['surfer_banner_height']));
    update_post_meta($post_id, '_surfer_banner_layout', sanitize_text_field($_POST['surfer_banner_layout']));
}
add_action('save_post', 'surfer_save_banner_meta');

/**
 * SURF SPOTS MODULE META BOX (for pages, posts, portfolios, galleries)
 */
function surfer_add_spots_module_metabox() {
    add_meta_box(
        'surfer_spots_module',
        '🌊 Surfer: Surf Spots Module',
        'surfer_spots_module_callback',
        array('page', 'post', 'portfolio', 'gallery', 'surfer_video'),
        'normal',
        'default'
    );
}
add_action('add_meta_boxes', 'surfer_add_spots_module_metabox');

function surfer_spots_module_callback($post) {
    $enabled  = get_post_meta($post->ID, '_surfer_spots_enabled', true);
    $count    = get_post_meta($post->ID, '_surfer_spots_count',   true) ?: '6';
    $cols     = get_post_meta($post->ID, '_surfer_spots_cols',    true) ?: '3';
    $title    = get_post_meta($post->ID, '_surfer_spots_title',   true) ?: 'Surf Spots';
    $subtitle = get_post_meta($post->ID, '_surfer_spots_subtitle',true) ?: 'Discover';
    $position = get_post_meta($post->ID, '_surfer_spots_position',true) ?: 'after';
    wp_nonce_field('surfer_spots_module_nonce', 'surfer_spots_module_nonce_field');
    ?>
    <div style="padding:12px;">
        <p>
            <label>
                <input type="checkbox" name="surfer_spots_enabled" <?php checked($enabled, 'on'); ?> value="on" id="surfer_spots_enabled">
                <strong>Show Surf Spots grid on this page</strong>
            </label>
        </p>
        <div id="surfer-spots-options" style="<?php echo ($enabled === 'on') ? '' : 'display:none;'; ?> background:#f9f9f9; border:1px solid #e0e0e0; border-radius:6px; padding:16px; margin-top:10px;">
            <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:16px;">
                <div>
                    <label style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Number of Spots</label>
                    <input type="number" name="surfer_spots_count" value="<?php echo esc_attr($count); ?>" min="1" max="50" style="width:100%;">
                </div>
                <div>
                    <label style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Grid Columns</label>
                    <select name="surfer_spots_cols" style="width:100%;">
                        <option value="2" <?php selected($cols, '2'); ?>>2 Columns</option>
                        <option value="3" <?php selected($cols, '3'); ?>>3 Columns</option>
                        <option value="4" <?php selected($cols, '4'); ?>>4 Columns</option>
                    </select>
                </div>
                <div>
                    <label style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Position on Page</label>
                    <select name="surfer_spots_position" style="width:100%;">
                        <option value="before" <?php selected($position, 'before'); ?>>Before content</option>
                        <option value="after"  <?php selected($position, 'after');  ?>>After content</option>
                    </select>
                </div>
            </div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div>
                    <label style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Section Title</label>
                    <input type="text" name="surfer_spots_title" value="<?php echo esc_attr($title); ?>" style="width:100%;" placeholder="Surf Spots">
                </div>
                <div>
                    <label style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Eyebrow Label (above title)</label>
                    <input type="text" name="surfer_spots_subtitle" value="<?php echo esc_attr($subtitle); ?>" style="width:100%;" placeholder="Discover">
                </div>
            </div>
            <p style="margin-top:12px; font-size:12px; color:#888;">
                ℹ️ Spots are pulled from the <strong>Surf Spots</strong> post type. Only published spots appear. Configure each spot's technical data in its individual editor.
            </p>
        </div>
        <script>
        document.getElementById('surfer_spots_enabled').addEventListener('change', function(){
            document.getElementById('surfer-spots-options').style.display = this.checked ? '' : 'none';
        });
        </script>
    </div>
    <?php
}

function surfer_save_spots_module_meta($post_id) {
    if (!isset($_POST['surfer_spots_module_nonce_field']) || !wp_verify_nonce($_POST['surfer_spots_module_nonce_field'], 'surfer_spots_module_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    update_post_meta($post_id, '_surfer_spots_enabled',  $_POST['surfer_spots_enabled'] ?? '');
    update_post_meta($post_id, '_surfer_spots_count',    sanitize_text_field($_POST['surfer_spots_count']    ?? '6'));
    update_post_meta($post_id, '_surfer_spots_cols',     sanitize_text_field($_POST['surfer_spots_cols']     ?? '3'));
    update_post_meta($post_id, '_surfer_spots_title',    sanitize_text_field($_POST['surfer_spots_title']    ?? 'Surf Spots'));
    update_post_meta($post_id, '_surfer_spots_subtitle', sanitize_text_field($_POST['surfer_spots_subtitle'] ?? 'Discover'));
    update_post_meta($post_id, '_surfer_spots_position', sanitize_text_field($_POST['surfer_spots_position'] ?? 'after'));
}
add_action('save_post', 'surfer_save_spots_module_meta');

/**
 * Helper: render surf spots module from post meta (call in any template)
 */
function surfer_maybe_render_spots($post_id, $position_check = 'after') {
    $enabled  = get_post_meta($post_id, '_surfer_spots_enabled', true);
    if ($enabled !== 'on') return;
    $position = get_post_meta($post_id, '_surfer_spots_position', true) ?: 'after';
    if ($position !== $position_check) return;
    get_template_part('templates/surf-spots', null, array(
        'count'    => intval(get_post_meta($post_id, '_surfer_spots_count',    true) ?: 6),
        'cols'     => intval(get_post_meta($post_id, '_surfer_spots_cols',     true) ?: 3),
        'title'    => get_post_meta($post_id, '_surfer_spots_title',    true) ?: 'Surf Spots',
        'subtitle' => get_post_meta($post_id, '_surfer_spots_subtitle', true) ?: 'Discover',
    ));
}

/**
 * VIDEOS MODULE META BOX (for pages, posts, portfolios, galleries)
 */
function surfer_add_videos_module_metabox() {
    add_meta_box(
        'surfer_videos_module',
        '🎬 Surfer: Videos Module',
        'surfer_videos_module_callback',
        array('page', 'post', 'portfolio', 'gallery', 'surf_spot'),
        'normal',
        'default'
    );
}
add_action('add_meta_boxes', 'surfer_add_videos_module_metabox');

function surfer_videos_module_callback($post) {
    $enabled  = get_post_meta($post->ID, '_surfer_videos_enabled', true);
    $count    = get_post_meta($post->ID, '_surfer_videos_count',   true) ?: '3';
    $cols     = get_post_meta($post->ID, '_surfer_videos_cols',    true) ?: '3';
    $title    = get_post_meta($post->ID, '_surfer_videos_title',   true) ?: 'Latest Videos';
    $subtitle = get_post_meta($post->ID, '_surfer_videos_subtitle',true) ?: 'Watch';
    $position = get_post_meta($post->ID, '_surfer_videos_position',true) ?: 'after';
    wp_nonce_field('surfer_videos_module_nonce', 'surfer_videos_module_nonce_field');
    ?>
    <div style="padding:12px;">
        <p>
            <label>
                <input type="checkbox" name="surfer_videos_enabled" <?php checked($enabled, 'on'); ?> value="on" id="surfer_videos_enabled">
                <strong>Show Videos grid on this page</strong>
            </label>
        </p>
        <div id="surfer-videos-options" style="<?php echo ($enabled === 'on') ? '' : 'display:none;'; ?> background:#f9f9f9; border:1px solid #e0e0e0; border-radius:6px; padding:16px; margin-top:10px;">
            <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:16px;">
                <div>
                    <label style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Number of Videos</label>
                    <input type="number" name="surfer_videos_count" value="<?php echo esc_attr($count); ?>" min="1" max="50" style="width:100%;">
                </div>
                <div>
                    <label style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Grid Columns</label>
                    <select name="surfer_videos_cols" style="width:100%;">
                        <option value="2" <?php selected($cols, '2'); ?>>2 Columns</option>
                        <option value="3" <?php selected($cols, '3'); ?>>3 Columns</option>
                        <option value="4" <?php selected($cols, '4'); ?>>4 Columns</option>
                    </select>
                </div>
                <div>
                    <label style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Position on Page</label>
                    <select name="surfer_videos_position" style="width:100%;">
                        <option value="before" <?php selected($position, 'before'); ?>>Before content</option>
                        <option value="after"  <?php selected($position, 'after');  ?>>After content</option>
                    </select>
                </div>
            </div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div>
                    <label style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Section Title</label>
                    <input type="text" name="surfer_videos_title" value="<?php echo esc_attr($title); ?>" style="width:100%;" placeholder="Latest Videos">
                </div>
                <div>
                    <label style="font-size:12px; display:block; margin-bottom:4px; font-weight:600;">Eyebrow Label (above title)</label>
                    <input type="text" name="surfer_videos_subtitle" value="<?php echo esc_attr($subtitle); ?>" style="width:100%;" placeholder="Watch">
                </div>
            </div>
            <p style="margin-top:12px; font-size:12px; color:#888;">
                ℹ️ Videos are pulled from the <strong>Videos</strong> post type. Only published videos appear.
            </p>
        </div>
        <script>
        document.getElementById('surfer_videos_enabled').addEventListener('change', function(){
            document.getElementById('surfer-videos-options').style.display = this.checked ? '' : 'none';
        });
        </script>
    </div>
    <?php
}

function surfer_save_videos_module_meta($post_id) {
    if (!isset($_POST['surfer_videos_module_nonce_field']) || !wp_verify_nonce($_POST['surfer_videos_module_nonce_field'], 'surfer_videos_module_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    update_post_meta($post_id, '_surfer_videos_enabled',  $_POST['surfer_videos_enabled'] ?? '');
    update_post_meta($post_id, '_surfer_videos_count',    sanitize_text_field($_POST['surfer_videos_count']    ?? '3'));
    update_post_meta($post_id, '_surfer_videos_cols',     sanitize_text_field($_POST['surfer_videos_cols']     ?? '3'));
    update_post_meta($post_id, '_surfer_videos_title',    sanitize_text_field($_POST['surfer_videos_title']    ?? 'Latest Videos'));
    update_post_meta($post_id, '_surfer_videos_subtitle', sanitize_text_field($_POST['surfer_videos_subtitle'] ?? 'Watch'));
    update_post_meta($post_id, '_surfer_videos_position', sanitize_text_field($_POST['surfer_videos_position'] ?? 'after'));
}
add_action('save_post', 'surfer_save_videos_module_meta');

/**
 * Helper: render videos module from post meta (call in any template)
 */
function surfer_maybe_render_videos($post_id, $position_check = 'after') {
    $enabled  = get_post_meta($post_id, '_surfer_videos_enabled', true);
    if ($enabled !== 'on') return;
    $position = get_post_meta($post_id, '_surfer_videos_position', true) ?: 'after';
    if ($position !== $position_check) return;
    get_template_part('templates/videos', null, array(
        'count'    => intval(get_post_meta($post_id, '_surfer_videos_count',    true) ?: 3),
        'cols'     => intval(get_post_meta($post_id, '_surfer_videos_cols',     true) ?: 3),
        'title'    => get_post_meta($post_id, '_surfer_videos_title',    true) ?: 'Latest Videos',
        'subtitle' => get_post_meta($post_id, '_surfer_videos_subtitle', true) ?: 'Watch',
        'layout'   => 'container', // Pages/posts always use container
    ));
}

