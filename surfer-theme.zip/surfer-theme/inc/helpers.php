<?php
/**
 * SURFER Unified Settings Helper - Elite Version
 */

function surfer_get_opt($key, $default = '') {
    // 1. Verificar Theme Mods (Customizer)
    $theme_mod = get_theme_mod($key);
    
    // Se o theme_mod existir e não for apenas espaços/vazio, usamos ele.
    if ( $theme_mod !== false && $theme_mod !== '' ) {
        return $theme_mod;
    }
    
    // 2. Verificar Options (Surfer Panel)
    $options = get_option('surfer_options');
    if ( is_array($options) && isset($options[$key]) && $options[$key] !== '' ) {
        return $options[$key];
    }

    // 3. Fallback final
    return $default;
}
