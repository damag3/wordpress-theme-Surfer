<?php
/**
 * SURFER Theme Options Panel - FULL RESTORATION v2.4.2
 */

function surfer_add_admin_menu() {
    add_menu_page('Surfer Panel', 'Surfer Panel', 'manage_options', 'surfer_options', 'surfer_options_page', 'dashicons-admin-generic', 2);
    add_menu_page('About Us', 'About Us', 'manage_options', 'surfer_bio', 'surfer_bio_page', 'dashicons-admin-users', 3);
}
add_action('admin_menu', 'surfer_add_admin_menu');

function surfer_admin_scripts($hook) {
    if (!in_array($hook, array('toplevel_page_surfer_options', 'toplevel_page_surfer_bio'))) return;
    wp_enqueue_media();
    wp_enqueue_style('surfer-admin-style', get_template_directory_uri() . '/assets/css/admin-panel.css');
    wp_enqueue_script('surfer-admin-js', get_template_directory_uri() . '/assets/js/admin-panel.js', array('jquery'), '2.4', true);
}
add_action('admin_enqueue_scripts', 'surfer_admin_scripts');

function surfer_options_page() {
    if (isset($_POST['surfer_save_action']) && check_admin_referer('surfer_options_verify')) {
        update_option('surfer_options', $_POST['surfer_options']);
        echo '<div class="updated"><p>Settings restored and saved successfully!</p></div>';
    }

    $options = get_option('surfer_options', array());
    $categories = get_terms(array('taxonomy' => 'portfolio_cat', 'hide_empty' => false));
    ?>
    <div class="surfer-dashboard">
        <aside class="surfer-sidebar">
            <div class="surfer-logo-area"><h2>SURFER</h2><span>v2.4.2</span></div>
            <nav class="surfer-nav">
                <a href="#branding" class="active"><span class="dashicons dashicons-art"></span> Branding</a>
                <a href="#layout"><span class="dashicons dashicons-layout"></span> Global Layout</a>
                <a href="#header"><span class="dashicons dashicons-menu-alt3"></span> Header & Nav</a>
                <a href="#appearance"><span class="dashicons dashicons-admin-appearance"></span> Global Style</a>
                <a href="#bio"><span class="dashicons dashicons-admin-users"></span> About (Bio)</a>
                <a href="#portfolio"><span class="dashicons dashicons-images-alt2"></span> Portfolio Grid</a>
                <a href="#footer"><span class="dashicons dashicons-editor-insertmore"></span> Footer</a>
                <a href="#social"><span class="dashicons dashicons-share"></span> Social Networks</a>
                <a href="#surf_spots_panel"><span class="dashicons dashicons-location-alt"></span> Surf Spots Module</a>
                <a href="#demo"><span class="dashicons dashicons-download"></span> Demo Import</a>
            </nav>
        </aside>

        <main class="surfer-main">
            <form method="post">
                <?php wp_nonce_field('surfer_options_verify'); ?>
                <input type="hidden" name="surfer_save_action" value="1">
                <header class="surfer-main-header">
                    <h1>Ultimate Theme Control</h1>
                    <input type="submit" class="button button-primary button-hero" value="Save All Changes">
                </header>

                <div class="surfer-sections">
                    
                    <!-- 1. BRANDING -->
                    <section id="branding" class="surfer-section active">
                        <h3>Logo & Identity</h3>
                        <div class="surfer-grid-2">
                            <div class="surfer-field">
                                <label>Light Logo</label>
                                <div class="media-input">
                                    <input type="text" name="surfer_options[logo_light]" id="logo_light" value="<?php echo esc_attr($options['logo_light'] ?? ''); ?>">
                                    <button class="button surfer-upload-button" data-input="logo_light">Upload</button>
                                </div>
                            </div>
                            <div class="surfer-field">
                                <label>Dark Logo</label>
                                <div class="media-input">
                                    <input type="text" name="surfer_options[logo_dark]" id="logo_dark" value="<?php echo esc_attr($options['logo_dark'] ?? ''); ?>">
                                    <button class="button surfer-upload-button" data-input="logo_dark">Upload</button>
                                </div>
                            </div>
                        </div>
                        <div class="surfer-grid-3 mt-20">
                            <div class="surfer-field"><label>Logo Height (px)</label><input type="number" name="surfer_options[logo_height]" value="<?php echo esc_attr($options['logo_height'] ?? '40'); ?>"></div>
                            <div class="surfer-field"><label>Logo Opacity (%)</label><input type="range" name="surfer_options[logo_opacity]" min="0" max="100" value="<?php echo esc_attr($options['logo_opacity'] ?? '100'); ?>"></div>
                            <div class="surfer-field"><label>Logo Position</label><select name="surfer_options[logo_position]"><option value="left" <?php selected($options['logo_position'] ?? '', 'left'); ?>>Left</option><option value="center" <?php selected($options['logo_position'] ?? '', 'center'); ?>>Center</option></select></div>
                        </div>
                    </section>

                    <!-- 2. GLOBAL LAYOUT -->
                    <section id="layout" class="surfer-section">
                        <h3>Global Layout & Containers</h3>
                        <p class="surfer-help">Configure the overall width and structure of your website.</p>

                        <!-- Main Site Settings -->
                        <div class="surfer-card-inner">
                            <div class="surfer-grid-2">
                                <div class="surfer-field">
                                    <label><strong>Site Wrapper Mode</strong></label>
                                    <select name="surfer_options[site_layout]">
                                        <option value="wide" <?php selected(($options['site_layout'] ?? 'wide'), 'wide'); ?>>Wide (Full Browser Width)</option>
                                        <option value="boxed" <?php selected(($options['site_layout'] ?? 'wide'), 'boxed'); ?>>Boxed Site (Max 1440px with background)</option>
                                    </select>
                                    <p class="surfer-help">Boxed layout wraps the entire site in a container.</p>
                                </div>
                                <div class="surfer-field">
                                    <label><strong>Max Container Width</strong></label>
                                    <select name="surfer_options[container_width]">
                                        <option value="1200px" <?php selected(($options['container_width'] ?? '1200px'), '1200px'); ?>>Standard (1200px)</option>
                                        <option value="1400px" <?php selected(($options['container_width'] ?? '1200px'), '1400px'); ?>>Wide (1400px)</option>
                                        <option value="1000px" <?php selected(($options['container_width'] ?? '1200px'), '1000px'); ?>>Narrow (1000px)</option>
                                    </select>
                                    <p class="surfer-help">The default width for all "Boxed" content modules.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Module Layouts Grid -->
                        <div class="surfer-sub-header">Module Layout Overrides</div>
                        <p class="surfer-help">Choose whether each module spans the full width (Wide) or stays within the container (Boxed).</p>
                        
                        <div class="surfer-grid-3">
                            <div class="surfer-field">
                                <label>Hero Banner</label>
                                <select name="surfer_options[hero_layout]">
                                    <option value="wide" <?php selected($options['hero_layout'] ?? '', 'wide'); ?>>Wide</option>
                                    <option value="boxed" <?php selected($options['hero_layout'] ?? '', 'boxed'); ?>>Boxed</option>
                                </select>
                            </div>
                            <div class="surfer-field">
                                <label>Gallery</label>
                                <select name="surfer_options[gallery_layout]">
                                    <option value="wide" <?php selected($options['gallery_layout'] ?? '', 'wide'); ?>>Wide</option>
                                    <option value="boxed" <?php selected($options['gallery_layout'] ?? '', 'boxed'); ?>>Boxed</option>
                                </select>
                            </div>
                            <div class="surfer-field">
                                <label>Portfolio</label>
                                <select name="surfer_options[portfolio_layout]">
                                    <option value="wide" <?php selected($options['portfolio_layout'] ?? '', 'wide'); ?>>Wide</option>
                                    <option value="boxed" <?php selected($options['portfolio_layout'] ?? '', 'boxed'); ?>>Boxed</option>
                                </select>
                            </div>
                        </div>

                        <div class="surfer-grid-3 mt-20">
                            <div class="surfer-field">
                                <label>Blog</label>
                                <select name="surfer_options[blog_layout]">
                                    <option value="wide" <?php selected($options['blog_layout'] ?? '', 'wide'); ?>>Wide</option>
                                    <option value="boxed" <?php selected($options['blog_layout'] ?? '', 'boxed'); ?>>Boxed</option>
                                </select>
                            </div>
                            <div class="surfer-field">
                                <label>Surf Spots</label>
                                <select name="surfer_options[surf_spots_layout]">
                                    <option value="wide" <?php selected($options['surf_spots_layout'] ?? '', 'wide'); ?>>Wide</option>
                                    <option value="boxed" <?php selected($options['surf_spots_layout'] ?? '', 'boxed'); ?>>Boxed</option>
                                </select>
                            </div>
                            <div class="surfer-field">
                                <label>Videos</label>
                                <select name="surfer_options[videos_layout]">
                                    <option value="wide" <?php selected($options['videos_layout'] ?? '', 'wide'); ?>>Wide</option>
                                    <option value="boxed" <?php selected($options['videos_layout'] ?? '', 'boxed'); ?>>Boxed</option>
                                </select>
                            </div>
                        </div>

                        <!-- Spacing -->
                        <div class="surfer-sub-header">Section Spacing</div>
                        <div class="surfer-grid-2">
                            <div class="surfer-field">
                                <label>Hero Height (e.g. 100vh, 600px)</label>
                                <input type="text" name="surfer_options[hero_height]" value="<?php echo esc_attr($options['hero_height'] ?? '100vh'); ?>" placeholder="100vh">
                            </div>
                            <div class="surfer-field">
                                <label>Vertical Gap between Sections (px)</label>
                                <input type="number" name="surfer_options[section_spacing]" value="<?php echo esc_attr($options['section_spacing'] ?? '120'); ?>">
                            </div>
                        </div>
                    </section>

                    <!-- 3. HEADER & NAVIGATION -->
                    <section id="header" class="surfer-section">
                        <h3>Header & Navigation Style</h3>
                        <div class="surfer-grid-2">
                            <div class="surfer-field"><label>Menu Text Color</label><input type="color" name="surfer_options[menu_color]" value="<?php echo esc_attr($options['menu_color'] ?? '#ffffff'); ?>"></div>
                            <div class="surfer-field"><label>Header BG Color</label><input type="color" name="surfer_options[header_bg_color]" value="<?php echo esc_attr($options['header_bg_color'] ?? '#000000'); ?>"></div>
                        </div>
                        <div class="surfer-grid-3 mt-20">
                            <div class="surfer-field"><label>Font Size (px)</label><input type="number" name="surfer_options[menu_size]" value="<?php echo esc_attr($options['menu_size'] ?? '10'); ?>"></div>
                            <div class="surfer-field">
                                <label>Transparency (%) <output id="transp-val"><?php echo esc_attr($options['header_transparency'] ?? '30'); ?></output></label>
                                <input type="range" name="surfer_options[header_transparency]" min="0" max="100" value="<?php echo esc_attr($options['header_transparency'] ?? '30'); ?>" oninput="document.getElementById('transp-val').value=this.value">
                            </div>
                            <div class="surfer-field"><label>Menu Position</label><select name="surfer_options[menu_position]"><option value="right" <?php selected($options['menu_position'] ?? '', 'right'); ?>>Right</option><option value="center" <?php selected($options['menu_position'] ?? '', 'center'); ?>>Center</option></select></div>
                        </div>
                        <div class="surfer-grid-2 mt-20">
                            <div class="surfer-field">
                                <label>Header Position</label>
                                <select name="surfer_options[header_fixed]">
                                    <option value="fixed"  <?php selected($options['header_fixed'] ?? 'fixed', 'fixed'); ?>>Fixed (stays at top while scrolling)</option>
                                    <option value="static" <?php selected($options['header_fixed'] ?? 'fixed', 'static'); ?>>Static (scrolls with page)</option>
                                </select>
                            </div>
                            <div class="surfer-field">
                                <label>Header Distance to Top (Padding in px)</label>
                                <input type="number" name="surfer_options[header_padding]" value="<?php echo esc_attr($options['header_padding'] ?? '40'); ?>">
                            </div>
                        </div>
                    </section>

                    <!-- 4. APPEARANCE -->
                    <section id="appearance" class="surfer-section">
                        <h3>Global Typography & Style</h3>
                        <div class="surfer-grid-2">
                            <div class="surfer-field">
                                <label>Title Font</label>
                                <select name="surfer_options[font_titles]">
                                    <option value="Playfair Display" <?php selected($options['font_titles'] ?? '', 'Playfair Display'); ?>>Playfair Display</option>
                                    <option value="Oswald" <?php selected($options['font_titles'] ?? '', 'Oswald'); ?>>Oswald</option>
                                    <option value="Inter" <?php selected($options['font_titles'] ?? '', 'Inter'); ?>>Inter</option>
                                </select>
                            </div>
                            <div class="surfer-field"><label>Primary Accent Color</label><input type="color" name="surfer_options[color_primary]" value="<?php echo esc_attr($options['color_primary'] ?? '#885121'); ?>"></div>
                        </div>
                        <div class="surfer-grid-2 mt-20">
                            <div class="surfer-field"><label>Site Background Color (Default: White)</label><input type="color" name="surfer_options[site_bg_color]" value="<?php echo esc_attr($options['site_bg_color'] ?? '#ffffff'); ?>"></div>
                            <div class="surfer-field"><label>Site Text Color (Default: Black)</label><input type="color" name="surfer_options[site_text_color]" value="<?php echo esc_attr($options['site_text_color'] ?? '#0a0a0a'); ?>"></div>
                        </div>
                        <div class="surfer-field mt-20"><label>Border Radius (px)</label><input type="number" name="surfer_options[border_radius]" value="<?php echo esc_attr($options['border_radius'] ?? '20'); ?>"></div>
                    </section>

                    <!-- 5. PORTFOLIO GRID -->
                    <section id="portfolio" class="surfer-section">
                        <h3>Portfolio Grid Settings</h3>
                        <div class="surfer-grid-2">
                            <div class="surfer-field"><label>Show on Front Page</label><input type="checkbox" name="surfer_options[show_portfolio_front]" <?php checked($options['show_portfolio_front'] ?? '', 'on'); ?> value="on"> <small>Display portfolio section on homepage</small></div>
                            <div class="surfer-field"><label>Number of Items</label><input type="number" min="1" max="50" name="surfer_options[portfolio_count]" value="<?php echo esc_attr($options['portfolio_count'] ?? '6'); ?>"></div>
                        </div>
                        
                        <div class="surfer-grid-3 mt-20">
                            <div class="surfer-field">
                                <label>Filter by Category</label>
                                <select name="surfer_options[portfolio_category]">
                                    <option value="all">All Categories</option>
                                    <?php foreach($categories as $cat) : ?><option value="<?php echo $cat->slug; ?>" <?php selected($options['portfolio_category'] ?? '', $cat->slug); ?>><?php echo $cat->name; ?></option><?php endforeach; ?>
                                </select>
                            </div>
                            <div class="surfer-field"><label>Grid Columns</label><select name="surfer_options[portfolio_cols]"><option value="2" <?php selected($options['portfolio_cols'] ?? '', '2'); ?>>2 Columns</option><option value="3" <?php selected($options['portfolio_cols'] ?? '', '3'); ?>>3 Columns</option><option value="4" <?php selected($options['portfolio_cols'] ?? '', '4'); ?>>4 Columns</option></select></div>
                            <div class="surfer-field"><label>Card Aspect Ratio</label><select name="surfer_options[portfolio_ratio]"><option value="4/5" <?php selected($options['portfolio_ratio'] ?? '', '4/5'); ?>>Portrait 4:5</option><option value="1/1" <?php selected($options['portfolio_ratio'] ?? '', '1/1'); ?>>Square 1:1</option><option value="16/9" <?php selected($options['portfolio_ratio'] ?? '', '16/9'); ?>>Landscape 16:9</option><option value="3/4" <?php selected($options['portfolio_ratio'] ?? '', '3/4'); ?>>Portrait 3:4</option></select></div>
                        </div>
                        <div class="surfer-grid-2 mt-20">
                            <div class="surfer-field"><label>Show Project Title</label><select name="surfer_options[portfolio_show_title]"><option value="yes" <?php selected($options['portfolio_show_title'] ?? 'yes', 'yes'); ?>>Yes</option><option value="no" <?php selected($options['portfolio_show_title'] ?? 'yes', 'no'); ?>>No (hover only)</option></select></div>
                            <div class="surfer-field"><label>Hover Effect</label><select name="surfer_options[portfolio_hover]"><option value="zoom" <?php selected($options['portfolio_hover'] ?? 'zoom', 'zoom'); ?>>Zoom In</option><option value="fade" <?php selected($options['portfolio_hover'] ?? 'zoom', 'fade'); ?>>Fade Overlay</option><option value="none" <?php selected($options['portfolio_hover'] ?? 'zoom', 'none'); ?>>None</option></select></div>
                        </div>
                    </section>

                    <!-- 6. ABOUT (BIO) -->
                    <section id="bio" class="surfer-section">
                        <h3>Biography & Profile</h3>
                        <p class="surfer-help">Configure your personal bio and social links for the "About" sections.</p>
                        <div class="surfer-card-inner">
                            <div class="surfer-grid-2">
                                <div class="surfer-field"><label>Title</label><input type="text" name="surfer_options[bio_title]" value="<?php echo esc_attr($options['bio_title'] ?? ''); ?>"></div>
                                <div class="surfer-field"><label>Subtitle</label><input type="text" name="surfer_options[bio_subtitle]" value="<?php echo esc_attr($options['bio_subtitle'] ?? ''); ?>"></div>
                            </div>
                            <div class="surfer-field mt-20"><label>Biography Text</label><textarea name="surfer_options[bio_text]" rows="6" style="width:100%;"><?php echo esc_textarea($options['bio_text'] ?? ''); ?></textarea></div>
                            <div class="surfer-field mt-20">
                                <label>Profile Image</label>
                                <div class="media-input">
                                    <input type="text" name="surfer_options[bio_image]" id="bio_image_panel" value="<?php echo esc_attr($options['bio_image'] ?? ''); ?>">
                                    <button class="button surfer-upload-button" data-input="bio_image_panel">Upload Image</button>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- 6. FOOTER -->
                    <section id="footer" class="surfer-section">
                        <h3>Footer & Copyright</h3>
                        <div class="surfer-field"><label>Copyright Text</label><input type="text" name="surfer_options[footer_copy]" value="<?php echo esc_attr($options['footer_copy'] ?? ''); ?>" class="widefat"></div>
                        <div class="surfer-grid-2 mt-20">
                            <div class="surfer-field"><label>Footer BG Color</label><input type="color" name="surfer_options[footer_bg_color]" value="<?php echo esc_attr($options['footer_bg_color'] ?? '#000000'); ?>"></div>
                            <div class="surfer-field"><label>Footer Text Color</label><input type="color" name="surfer_options[footer_text_color]" value="<?php echo esc_attr($options['footer_text_color'] ?? '#ffffff'); ?>"></div>
                        </div>
                        <div class="surfer-grid-2 mt-20">
                            <div class="surfer-field"><label>Columns (1-4)</label><select name="surfer_options[footer_columns]"><?php for($i=1;$i<=4;$i++) : ?><option value="<?php echo $i; ?>" <?php selected($options['footer_columns'] ?? '', $i); ?>><?php echo $i; ?> Col(s)</option><?php endfor; ?></select></div>
                            <div class="surfer-field"><label>Automated Date</label><input type="checkbox" name="surfer_options[footer_show_date]" <?php checked($options['footer_show_date'] ?? '', 'on'); ?> value="on"></div>
                        </div>
                    </section>

                    <!-- 7. SOCIAL NETWORKS -->
                    <section id="social" class="surfer-section">
                        <h3>Social Networks</h3>
                        <p style="color:#888;font-size:13px;margin-bottom:20px;">These links appear in the footer and About section. Add the preset networks below, then add custom ones as needed.</p>

                        <div class="surfer-grid-2">
                            <?php
                            $preset_socials = array(
                                'instagram' => array('label' => 'Instagram', 'icon' => '📸', 'placeholder' => 'https://instagram.com/yourname'),
                                'facebook'  => array('label' => 'Facebook',  'icon' => '👤', 'placeholder' => 'https://facebook.com/yourpage'),
                                'youtube'   => array('label' => 'YouTube',   'icon' => '▶️', 'placeholder' => 'https://youtube.com/@yourchannel'),
                                'tiktok'    => array('label' => 'TikTok',    'icon' => '🎵', 'placeholder' => 'https://tiktok.com/@yourname'),
                                'twitter'   => array('label' => 'X (Twitter)','icon' => '✕', 'placeholder' => 'https://x.com/yourname'),
                                'linkedin'  => array('label' => 'LinkedIn',  'icon' => '💼', 'placeholder' => 'https://linkedin.com/in/yourname'),
                                'vimeo'     => array('label' => 'Vimeo',     'icon' => '🎬', 'placeholder' => 'https://vimeo.com/yourname'),
                                'pinterest' => array('label' => 'Pinterest', 'icon' => '📌', 'placeholder' => 'https://pinterest.com/yourname'),
                            );
                            foreach ($preset_socials as $key => $info) :
                                $val = $options['social'][$key] ?? '';
                            ?>
                            <div class="surfer-field">
                                <label><?php echo $info['icon']; ?> <?php echo $info['label']; ?></label>
                                <input type="url" name="surfer_options[social][<?php echo $key; ?>]" value="<?php echo esc_attr($val); ?>" placeholder="<?php echo esc_attr($info['placeholder']); ?>">
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Custom Social Networks -->
                        <h4 style="margin-top:30px;margin-bottom:10px;">Custom Networks</h4>
                        <p style="color:#888;font-size:13px;margin-bottom:15px;">Add any other social network or link not listed above.</p>
                        <div id="surfer-custom-socials">
                            <?php
                            $custom_socials = $options['social_custom'] ?? array();
                            if (!is_array($custom_socials)) $custom_socials = array();
                            foreach ($custom_socials as $idx => $custom) :
                                $c_label = $custom['label'] ?? '';
                                $c_url   = $custom['url']   ?? '';
                            ?>
                            <div class="surfer-custom-social-row" style="display:flex;gap:10px;align-items:center;margin-bottom:10px;">
                                <input type="text" name="surfer_options[social_custom][<?php echo $idx; ?>][label]" value="<?php echo esc_attr($c_label); ?>" placeholder="Network name (e.g. Behance)" style="flex:1;">
                                <input type="url"  name="surfer_options[social_custom][<?php echo $idx; ?>][url]"   value="<?php echo esc_attr($c_url); ?>"   placeholder="https://..." style="flex:2;">
                                <button type="button" class="button surfer-remove-social" style="color:red;">✕</button>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" id="surfer-add-social" class="button" style="margin-top:10px;">+ Add Custom Network</button>

                        <script>
                        (function(){
                            var container = document.getElementById('surfer-custom-socials');
                            var idx = <?php echo max(count($custom_socials), 0); ?>;
                            document.getElementById('surfer-add-social').addEventListener('click', function(){
                                var row = document.createElement('div');
                                row.className = 'surfer-custom-social-row';
                                row.style.cssText = 'display:flex;gap:10px;align-items:center;margin-bottom:10px;';
                                row.innerHTML = '<input type="text" name="surfer_options[social_custom]['+idx+'][label]" placeholder="Network name (e.g. Behance)" style="flex:1;">'
                                    + '<input type="url" name="surfer_options[social_custom]['+idx+'][url]" placeholder="https://..." style="flex:2;">'
                                    + '<button type="button" class="button surfer-remove-social" style="color:red;">✕</button>';
                                container.appendChild(row);
                                idx++;
                                row.querySelector('.surfer-remove-social').addEventListener('click', function(){ row.remove(); });
                            });
                            document.querySelectorAll('.surfer-remove-social').forEach(function(btn){
                                btn.addEventListener('click', function(){ btn.closest('.surfer-custom-social-row').remove(); });
                            });
                        })();
                        </script>
                    </section>

                    <!-- 9. SURF SPOTS MODULE -->
                    <section id="surf_spots_panel" class="surfer-section">
                        <h3>Surf Spots Module</h3>
                        <p style="color:#666;font-size:13px;margin-bottom:24px;">The Surf Spots module can be placed on the front page or any page/post using the shortcode below. Configure each spot's technical details in <strong>Surf Spots &rarr; Edit Spot</strong>.</p>

                        <!-- HOW TO USE -->
                        <div style="background:#f0f6fc;border:1px solid #bcd;border-radius:8px;padding:20px;margin-bottom:24px;">
                            <h4 style="margin:0 0 12px;color:#0073aa;">&#128274; How to add Surf Spots to any page or post</h4>
                            <p style="margin:0 0 10px;font-size:13px;"><strong>Option 1 — Front Page:</strong> Go to <a href="<?php echo admin_url('customize.php?autofocus[section]=surfer_spots_edit'); ?>" target="_blank">Appearance &rarr; Customize &rarr; Front Page Builder &rarr; 6. Surf Spots Module</a>, tick <em>&quot;Show Surf Spots on Front Page&quot;</em> and Save. You can then drag the module to any position using the Section Order panel.</p>
                            <hr style="margin:12px 0;border-color:#bcd;">
                            <p style="margin:0 0 8px;font-size:13px;"><strong>Option 2 — Shortcode (any page, post, or widget):</strong> Paste the shortcode below into any page or post content:</p>
                            <div style="background:#1e1e2e;color:#cdd6f4;font-family:monospace;padding:14px 18px;border-radius:6px;font-size:13px;margin-bottom:10px;user-select:all;">[surfer_spots count="6" cols="3" title="Surf Spots" subtitle="Discover"]</div>
                            <p style="margin:0;font-size:12px;color:#888;">Copy and paste the shortcode. You can customise the attributes below:</p>
                        </div>

                        <!-- ATTRIBUTE REFERENCE -->
                        <h4 style="margin-bottom:12px;">Shortcode Attributes</h4>
                        <table style="width:100%;border-collapse:collapse;font-size:13px;">
                            <thead>
                                <tr style="background:#f5f5f5;">
                                    <th style="padding:8px 12px;text-align:left;border:1px solid #ddd;">Attribute</th>
                                    <th style="padding:8px 12px;text-align:left;border:1px solid #ddd;">Default</th>
                                    <th style="padding:8px 12px;text-align:left;border:1px solid #ddd;">Options</th>
                                    <th style="padding:8px 12px;text-align:left;border:1px solid #ddd;">Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td style="padding:8px 12px;border:1px solid #ddd;"><code>count</code></td><td style="padding:8px 12px;border:1px solid #ddd;">6</td><td style="padding:8px 12px;border:1px solid #ddd;">Any number</td><td style="padding:8px 12px;border:1px solid #ddd;">How many spots to display</td></tr>
                                <tr><td style="padding:8px 12px;border:1px solid #ddd;"><code>cols</code></td><td style="padding:8px 12px;border:1px solid #ddd;">3</td><td style="padding:8px 12px;border:1px solid #ddd;">2, 3, 4</td><td style="padding:8px 12px;border:1px solid #ddd;">Number of columns in the grid</td></tr>
                                <tr><td style="padding:8px 12px;border:1px solid #ddd;"><code>title</code></td><td style="padding:8px 12px;border:1px solid #ddd;">Surf Spots</td><td style="padding:8px 12px;border:1px solid #ddd;">Any text</td><td style="padding:8px 12px;border:1px solid #ddd;">Main heading shown above the grid</td></tr>
                                <tr><td style="padding:8px 12px;border:1px solid #ddd;"><code>subtitle</code></td><td style="padding:8px 12px;border:1px solid #ddd;">Discover</td><td style="padding:8px 12px;border:1px solid #ddd;">Any text</td><td style="padding:8px 12px;border:1px solid #ddd;">Small label shown above the title</td></tr>
                            </tbody>
                        </table>

                        <!-- SHORTCODE BUILDER -->
                        <h4 style="margin-top:24px;margin-bottom:12px;">Shortcode Builder</h4>
                        <p style="color:#888;font-size:12px;margin-bottom:12px;">Fill in the fields and the shortcode is generated automatically. Copy &amp; paste it into any page.</p>
                        <div style="display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px;margin-bottom:12px;">
                            <div><label style="font-size:12px;display:block;margin-bottom:4px;">Number of Spots</label><input type="number" id="sb_count" value="6" min="1" max="50" style="width:100%;" oninput="surferBuildShortcode()"></div>
                            <div><label style="font-size:12px;display:block;margin-bottom:4px;">Columns</label><select id="sb_cols" style="width:100%;" onchange="surferBuildShortcode()"><option value="2">2</option><option value="3" selected>3</option><option value="4">4</option></select></div>
                            <div><label style="font-size:12px;display:block;margin-bottom:4px;">Title</label><input type="text" id="sb_title" value="Surf Spots" style="width:100%;" oninput="surferBuildShortcode()"></div>
                            <div><label style="font-size:12px;display:block;margin-bottom:4px;">Subtitle</label><input type="text" id="sb_subtitle" value="Discover" style="width:100%;" oninput="surferBuildShortcode()"></div>
                        </div>
                        <div style="position:relative;">
                            <div id="sb_output" style="background:#1e1e2e;color:#cdd6f4;font-family:monospace;padding:14px 18px;border-radius:6px;font-size:13px;user-select:all;">[surfer_spots count="6" cols="3" title="Surf Spots" subtitle="Discover"]</div>
                            <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('sb_output').textContent).then(function(){this.textContent='Copied!';setTimeout(function(){document.querySelector('.sb-copy-btn').textContent='Copy Shortcode';},1500);}.bind(this))" class="sb-copy-btn" style="position:absolute;top:8px;right:8px;background:#0073aa;color:#fff;border:none;padding:5px 12px;border-radius:4px;cursor:pointer;font-size:11px;">Copy Shortcode</button>
                        </div>
                        <script>
                        function surferBuildShortcode() {
                            var count = document.getElementById('sb_count').value || '6';
                            var cols  = document.getElementById('sb_cols').value  || '3';
                            var title = document.getElementById('sb_title').value || 'Surf Spots';
                            var sub   = document.getElementById('sb_subtitle').value || 'Discover';
                            document.getElementById('sb_output').textContent =
                                '[surfer_spots count="'+count+'" cols="'+cols+'" title="'+title+'" subtitle="'+sub+'"]';
                        }
                        </script>

                        <p style="margin-top:20px;font-size:12px;color:#888;">&#8505; Spots only appear if they have been published in <strong>Surf Spots</strong> in the left menu. Each spot's technical details (Wave Type, Tide, Level, etc.) are configured individually in the spot editor.</p>
                    </section>

                    <!-- 10. DEMO IMPORT -->
                    <section id="demo" class="surfer-section"><h3>Demo Import</h3><p>Import demo content to get started.</p><a href="<?php echo admin_url('themes.php?page=one-click-demo-import'); ?>" class="button button-hero button-primary">Go to Import</a></section>

                </div>
            </form>
        </main>
    </div>
    <?php
}

/**
 * PÁGINA SOBRE NÓS (BIO)
 */
function surfer_bio_page() {
    if (isset($_POST['surfer_bio_save']) && check_admin_referer('surfer_bio_verify')) {
        update_option('surfer_bio_options', $_POST['surfer_bio']);
        echo '<div class="updated"><p>Biography and Social Networks updated!</p></div>';
    }
    $bio = get_option('surfer_bio_options', array());
    $socials = array('instagram' => 'Instagram', 'youtube' => 'YouTube', 'facebook' => 'Facebook', 'vimeo' => 'Vimeo', 'tiktok' => 'TikTok', 'twitter' => 'X (Twitter)', 'linkedin' => 'LinkedIn');
    ?>
    <div class="surfer-dashboard">
        <main class="surfer-main" style="margin-left:0; width:100%;">
            <form method="post">
                <?php wp_nonce_field('surfer_bio_verify'); ?>
                <input type="hidden" name="surfer_bio_save" value="1">
                <header class="surfer-main-header"><h1>Biography & Social Media Management</h1><input type="submit" class="button button-primary button-hero" value="Save All"></header>
                <div class="surfer-sections">
                    <section class="surfer-section active">
                        <h3>Profile & Social</h3>
                        <div class="surfer-grid-2">
                            <div class="surfer-field"><label>Title</label><input type="text" name="surfer_bio[title]" value="<?php echo esc_attr($bio['title'] ?? ''); ?>" class="widefat"></div>
                            <div class="surfer-field"><label>Subtitle</label><input type="text" name="surfer_bio[subtitle]" value="<?php echo esc_attr($bio['subtitle'] ?? ''); ?>" class="widefat"></div>
                        </div>
                        <div class="surfer-field mt-20"><label>Biography</label><textarea name="surfer_bio[text]" rows="8" class="widefat"><?php echo esc_textarea($bio['text'] ?? ''); ?></textarea></div>
                        <div class="surfer-field mt-20">
                            <label>Profile Image</label>
                            <input type="text" name="surfer_bio[image]" id="bio_image" value="<?php echo esc_attr($bio['image'] ?? ''); ?>">
                            <button class="button surfer-upload-button" data-input="bio_image">Upload</button>
                        </div>
                        <div class="surfer-grid-2 mt-20">
                            <?php foreach($socials as $id => $label) : ?>
                                <div class="surfer-field"><label><?php echo $label; ?></label><input type="url" name="surfer_bio[social_<?php echo $id; ?>]" value="<?php echo esc_attr($bio['social_'.$id] ?? ''); ?>"></div>
                            <?php endforeach; ?>
                        </div>
                    </section>
                </div>
            </form>
        </main>
    </div>
    <?php
}
