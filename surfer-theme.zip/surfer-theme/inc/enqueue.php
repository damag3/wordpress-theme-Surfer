<?php
/**
 * Enqueue scripts and styles for SURFER theme
 */

function surfer_enqueue_scripts() {
    $options = get_option('surfer_options', array());
    
    // Theme Styles
    wp_enqueue_style('surfer-main', get_template_directory_uri() . '/assets/css/main.css', array(), SURFER_VERSION);
    wp_enqueue_style('surfer-wp-style', get_stylesheet_uri(), array(), SURFER_VERSION);
    
    // Google Fonts & Icons
    $font_titles = $options['font_titles'] ?? 'Playfair Display';
    $font_body   = $options['font_body']   ?? 'Inter';
    $font_url    = "https://fonts.googleapis.com/css2?family=" . urlencode($font_titles) . ":wght@400;700&family=" . urlencode($font_body) . ":wght@400;500;600;700&display=swap";
    wp_enqueue_style('google-fonts', $font_url, array(), null);
    wp_enqueue_style('material-symbols', 'https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap', array(), null);
    
    // Swiper CSS
    wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), null);
    
    // Scripts
    wp_enqueue_script('gsap',        'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js', array(), null, true);
    wp_enqueue_script('gsap-scroll', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js', array('gsap'), null, true);
    wp_enqueue_script('swiper-js',   'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), null, true);
    wp_enqueue_script('imagesloaded','https://unpkg.com/imagesloaded@5/imagesloaded.pkgd.min.js', array(), null, true);
    wp_enqueue_script('masonry',     'https://unpkg.com/masonry-layout@4/dist/masonry.pkgd.min.js', array('imagesloaded'), null, true);
    wp_enqueue_script('surfer-main', get_template_directory_uri() . '/assets/js/main.js', array('gsap', 'swiper-js'), SURFER_VERSION, true);

    // ============================================================
    // DYNAMIC STYLES — sync all Surfer Panel settings to CSS vars
    // ============================================================
    $primary         = esc_attr($options['color_primary']        ?? '#885121');
    $color_link      = esc_attr($options['color_link']           ?? '#885121');
    $font_serif      = esc_attr($font_titles);
    $font_body_opt   = esc_attr($options['font_body']            ?? 'Inter');
    $font_size_body  = intval($options['font_size_body']         ?? 16);
    $line_height     = floatval($options['line_height']          ?? 1.7);
    $letter_spacing  = floatval($options['letter_spacing']       ?? 0);
    
    // Base Colors
    $site_bg         = esc_attr($options['site_bg_color']        ?? '#ffffff');
    $site_text       = esc_attr($options['site_text_color']      ?? '#0a0a0a');

    // Header
    $menu_color      = esc_attr($options['menu_color']           ?? '#ffffff');
    $header_bg       = esc_attr($options['header_bg_color']      ?? '#000000');
    $menu_size       = intval($options['menu_size']              ?? 10);
    $transparency    = intval($options['header_transparency']    ?? 70);
    $menu_position   = esc_attr($options['menu_position']        ?? 'right');
    $header_padding  = intval($options['header_padding']         ?? 40);
    $header_fixed    = esc_attr($options['header_fixed']         ?? 'fixed');
    $header_alpha    = round((100 - $transparency) / 100, 2);

    // Footer
    $footer_bg      = esc_attr($options['footer_bg_color']      ?? '#000000');
    $footer_text    = esc_attr($options['footer_text_color']    ?? '#ffffff');
    $footer_padding = intval($options['footer_padding']         ?? 80);

    // Logo
    $logo_h         = intval($options['logo_height']            ?? 40);
    $logo_opacity   = intval($options['logo_opacity']           ?? 100) / 100;
    $logo_position  = esc_attr($options['logo_position']        ?? 'left');

    // Portfolio
    $portfolio_ratio = esc_attr($options['portfolio_ratio']     ?? '4/5');

    // Border Radius & Spacing
    $radius          = intval($options['border_radius']         ?? 0);
    $section_spacing = intval($options['section_spacing']       ?? 120);
    $container_width = esc_attr($options['container_width']     ?? '1200px');

    // Build menu justification
    $menu_justify = ($menu_position === 'center') ? 'center' : 'flex-end';
    $logo_align   = ($logo_position  === 'center') ? 'center' : 'flex-start';

    // Contrast logic for sticky header
    $bg_hex = str_replace('#', '', $header_bg);
    if (strlen($bg_hex) == 3) {
        $r = hexdec(substr($bg_hex,0,1).substr($bg_hex,0,1));
        $g = hexdec(substr($bg_hex,1,1).substr($bg_hex,1,1));
        $b = hexdec(substr($bg_hex,2,1).substr($bg_hex,2,1));
    } else if (strlen($bg_hex) == 6) {
        $r = hexdec(substr($bg_hex,0,2));
        $g = hexdec(substr($bg_hex,2,2));
        $b = hexdec(substr($bg_hex,4,2));
    } else {
        $r = 255; $g = 255; $b = 255;
    }
    $yiq = (($r*299)+($g*587)+($b*114))/1000;
    $sticky_text = ($yiq >= 128) ? '#000000' : '#ffffff';

    $custom_css = "
        :root {
            --color-bg:          {$site_bg};
            --color-text:        {$site_text};
            --color-accent:      {$primary};
            --color-link:        {$color_link};
            --font-serif:        '{$font_serif}', serif;
            --font-sans:         '{$font_body_opt}', sans-serif;
            --font-size-body:    {$font_size_body}px;
            --line-height-body:  {$line_height};
            --letter-spacing:    {$letter_spacing}em;
            --menu-color:        {$menu_color};
            --menu-font-size:    {$menu_size}px;
            --header-bg:         {$header_bg};
            --header-alpha:      {$header_alpha};
            --header-padding:    {$header_padding}px;
            --footer-bg:         {$footer_bg};
            --footer-text:       {$footer_text};
            --footer-padding:    {$footer_padding}px;
            --logo-height:       {$logo_h}px;
            --logo-opacity:      {$logo_opacity};
            --border-radius:     {$radius}px;
            --section-padding:   {$section_spacing}px;
            --portfolio-ratio:   {$portfolio_ratio};
            --container-max-width: {$container_width};
        }

        /* ── Body ── */
        body { font-size: var(--font-size-body); line-height: var(--line-height-body); letter-spacing: var(--letter-spacing); font-family: var(--font-sans); }
        a { color: var(--color-link); }

        /* ── Header ── */
        .site-header { color: var(--menu-color); position: {$header_fixed}; }
        .site-header.is-transparent { background-color: rgba({$r},{$g},{$b},{$header_alpha}); }
        .site-header .main-menu-list { justify-content: {$menu_justify}; }
        .site-header .logo { justify-content: {$logo_align}; }
        .main-menu-list a  { color: inherit; font-size: var(--menu-font-size); }
        .site-header.is-sticky { background-color: {$header_bg}; color: {$sticky_text}; }
        .site-header.is-sticky .theme-toggle { border-color: {$sticky_text}; }
        .logo-img { height: var(--logo-height); opacity: var(--logo-opacity); transition: filter 0.3s ease; }
        .site-header.is-sticky .logo-img { filter: " . ($sticky_text === '#ffffff' ? 'brightness(0) invert(1)' : 'brightness(0)') . "; }

        /* ── Footer ── */
        .site-footer { background-color: var(--footer-bg) !important; color: var(--footer-text) !important; padding-top: var(--footer-padding) !important; }
        .footer-bottom { border-color: rgba(255,255,255,0.1); }

        /* ── Cards / Radius ── */
        .card-image, .gallery-item { border-radius: var(--border-radius); }
        .card-image { aspect-ratio: var(--portfolio-ratio); }
    ";
    wp_add_inline_style('surfer-main', $custom_css);
}
add_action('wp_enqueue_scripts', 'surfer_enqueue_scripts');
