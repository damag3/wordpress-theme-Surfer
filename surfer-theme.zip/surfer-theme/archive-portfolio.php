<?php
/**
 * The template for displaying Portfolio Archive
 */

get_header(); ?>

<main class="site-main section-padding">
    <div class="container">
        <header class="archive-header mb-3xl">
            <h1 class="text-uppercase"><?php post_type_archive_title(); ?></h1>
            <?php the_archive_description('<div class="archive-description opacity-50">', '</div>'); ?>
        </header>

        <div class="grid grid-3">
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class('card'); ?>>
                    <a href="<?php the_permalink(); ?>" class="card-link">
                        <div class="card-image">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('large'); ?>
                            <?php else : ?>
                                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/placeholder.jpg" alt="<?php the_title(); ?>">
                            <?php endif; ?>
                        </div>
                        <div class="card-content">
                            <?php
                            $terms = get_the_terms(get_the_ID(), 'portfolio_cat');
                            if ($terms && !is_wp_error($terms)) :
                                echo '<span class="card-category">' . esc_html($terms[0]->name) . '</span>';
                            endif;
                            ?>
                            <h2 class="card-title"><?php the_title(); ?></h2>
                        </div>
                    </a>
                </article>
            <?php endwhile; ?>
                <div class="pagination">
                    <?php the_posts_pagination(); ?>
                </div>
            <?php else : ?>
                <p><?php esc_html_e('No projects found.', 'surfer'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
