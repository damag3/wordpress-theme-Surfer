<?php get_header(); ?>

<main class="pt-48 pb-32 container-custom">
    <header class="max-w-4xl mx-auto px-10 mb-20 text-center surfer-fade">
        <span class="text-[10px] uppercase tracking-[0.5em] opacity-40 block mb-6">Search Results</span>
        <h1 class="font-display text-5xl md:text-7xl uppercase tracking-tighter mb-8 italic">"<?php echo get_search_query(); ?>"</h1>
    </header>

    <div class="max-w-4xl mx-auto px-10">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <article class="mb-20 border-b border-black/5 dark:border-white/5 pb-20 surfer-fade">
                <span class="text-[9px] uppercase tracking-[0.4em] text-primary block mb-4"><?php echo get_post_type(); ?></span>
                <h2 class="font-display text-4xl uppercase tracking-tight mb-6"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <div class="prose dark:prose-invert opacity-60">
                    <?php the_excerpt(); ?>
                </div>
            </article>
        <?php endwhile; else : ?>
            <div class="text-center opacity-40 font-body-md py-20">No results found for your search.</div>
        <?php endif; ?>
    </div>
</main>

<?php get_footer(); ?>
