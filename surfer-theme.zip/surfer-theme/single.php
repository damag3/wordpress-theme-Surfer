<?php get_header(); ?>

<main id="primary" class="site-main">

    <?php while ( have_posts() ) : the_post(); ?>

        <?php 
        $show_banner = get_post_meta(get_the_ID(), '_surfer_show_banner', true) === 'on';
        ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            
            <?php if (!$show_banner) : ?>
                <!-- Header normal se não houver banner -->
                <header class="py-32 bg-black text-white px-10 text-center rounded-b-[60px]">
                    <div class="max-w-4xl mx-auto">
                        <span class="text-[10px] uppercase tracking-[0.6em] opacity-40 mb-6 block"><?php echo get_the_date(); ?></span>
                        <h1 class="font-display text-5xl md:text-7xl uppercase tracking-tighter leading-none"><?php the_title(); ?></h1>
                    </div>
                </header>
            <?php endif; ?>

            <!-- Post Content -->
            <div class="container py-24 surfer-reveal-up">
                <?php surfer_maybe_render_spots(get_the_ID(), 'before'); ?>
                <?php surfer_maybe_render_videos(get_the_ID(), 'before'); ?>
                <?php if (has_post_thumbnail() && !$show_banner) : ?>
                    <div class="rounded-custom overflow-hidden mb-16 shadow-2xl">
                        <?php the_post_thumbnail('full', array('class' => 'w-full h-auto')); ?>
                    </div>
                <?php endif; ?>

                <div class="prose prose-xl prose-stone mx-auto">
                    <?php the_content(); ?>
                </div>

                <!-- Post Footer -->
                <footer class="mt-24 pt-12 border-t border-black/5 flex justify-between items-center">
                    <div class="tags text-[10px] uppercase tracking-widest opacity-40">
                        <?php the_category(', '); ?>
                    </div>
                    <div class="share-links">
                        <?php get_template_part('templates/social-links', null, array('label' => 'Follow:')); ?>
                    </div>
                </footer>
            </div>
            <?php surfer_maybe_render_spots(get_the_ID(), 'after'); ?>
            <?php surfer_maybe_render_videos(get_the_ID(), 'after'); ?>

        </article>

    <?php endwhile; ?>

</main>

<?php get_footer(); ?>
