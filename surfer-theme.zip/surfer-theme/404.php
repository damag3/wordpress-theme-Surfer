<?php get_header(); ?>

<main class="h-screen w-full flex items-center justify-center text-center px-10">
    <div class="surfer-fade">
        <h1 class="font-display text-[20vw] md:text-[15vw] uppercase tracking-tighter leading-none mb-8 opacity-5">404</h1>
        <h2 class="font-display text-4xl md:text-6xl uppercase tracking-tighter mb-12">Lost in the <span class="text-primary italic">Fog</span>.</h2>
        <a href="<?php echo home_url(); ?>" class="inline-block border border-black/20 dark:border-white/20 px-12 py-5 text-[10px] uppercase tracking-[0.5em] hover:bg-black/5 dark:hover:bg-white/5 transition-colors">Return Home</a>
    </div>
</section>

<?php get_footer(); ?>
