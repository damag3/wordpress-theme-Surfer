<?php
/**
 * The template for displaying Gallery Archive
 */

get_header(); ?>

<main class="site-main section-padding">
    <div class="container">
        <header class="archive-header mb-3xl">
            <h1 class="text-uppercase"><?php post_type_archive_title(); ?></h1>
            <?php the_archive_description('<div class="archive-description opacity-50">', '</div>'); ?>
        </header>

        <div class="gallery-grid masonry">
            <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class('gallery-item'); ?>>
                    <a href="<?php the_permalink(); ?>">
                        <?php if (has_post_thumbnail()) : ?>
                            <?php the_post_thumbnail('large'); ?>
                        <?php endif; ?>
                        <div class="gallery-overlay">
                            <h2 class="text-sm text-uppercase"><?php the_title(); ?></h2>
                        </div>
                    </a>
                </article>
            <?php endwhile; ?>
            <?php else : ?>
                <p><?php esc_html_e('No galleries found.', 'surfer'); ?></p>
            <?php endif; ?>
        </div>
        
        <div class="pagination mt-2xl">
            <?php the_posts_pagination(); ?>
        </div>
    </div>
</main>

<?php get_footer(); ?>
